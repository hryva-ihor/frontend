const sports = [
	['🤺','fencing'],
	['⛸','figure skating'],
	['⛷','skier'],
	['🏂','snowboarder'],
	['🏌','golfing'],
	['🚣','rowing boat'],
	['🏊','swimming'],
	['🤸','gymnastics'],
	['🤾','handball']
];

const winners = [
	['fencing','gold','fr'],
	['fencing','silver','it'],
	['fencing','bronze','us'],

	['figure skating','gold','ca'],
	['figure skating','silver','ru'],
	['figure skating','bronze','us'],

	['skier','gold','no'],
	['skier','silver','ru'],
	['skier','bronze','fr'],

	['snowboarder','gold','us'],
	['snowboarder','silver','jp'],
	['snowboarder','bronze','au'],

	['golfing','gold','gb'],
	['golfing','silver','se'],
	['golfing','bronze','us'],

	['rowing boat','gold','us'],
	['rowing boat','silver','gb'],
	['rowing boat','bronze','ro'],

	['swimming','gold','us'],
	['swimming','silver','gb'],
	['swimming','bronze','au'],

	['gymnastics','gold','ru'],
	['gymnastics','silver','ru'],
	['gymnastics','bronze','ua'],

	['handball','gold','dk'],
	['handball','silver','fr'],
	['handball','bronze','de'],
];

const olympic = ['🔵','⚫','🔴','🟡','🟢'];

const medals = [
	['🥇','gold'],
	['🥈','silver'],
	['🥉','bronze'],
];

const continents = [
	['fr','Europe'],
	['it','Europe'],
	['us','The Americas'],
	['ca','The Americas'],
	['ru','Europe'],
	['no','Europe'],
	['jp','Asia'],
	['au','Oceania'],
	['gb','Europe'],
	['se','Europe'],
	['ro','Europe'],
	['ua','Europe'],
	['dk','Europe'],
	['de','Europe']
];

const flags = [
	['fr','🇫🇷'],
	['it','🇮🇹'],
	['us','🇺🇸'],
	['ca','🇨🇦'],
	['ru','🇷🇺'],
	['no','🇳🇴'],
	['jp','🇯🇵'],
	['au','🇦🇺'],
	['gb','🇬🇧'],
	['se','🇸🇪'],
	['ro','🇷🇴'],
	['ua','🇺🇦'],
	['dk','🇩🇰'],
	['de','🇩🇪']
];

function getContinentByCountry(country){
	let currentCountry = continents
		.find(function(item){
			return item[0] === country;
		});

	return currentCountry[1];
}

function getIconForMedal(medal){
	let iconMedal = medals
		.find(function(item){
			return item[1] === medal;
		}); // ['🥇','gold']

	return iconMedal[0];
}

const THs = olympic
	.map(function(circle){
		return `<th>${circle}</th>`;
	})
	.join(``);


const TRs = sports
	.map(function(sport){ // ['🤺','fencing']
		let sportIcon = sport[0],
			sportName = sport[1];

		//console.log(sportName);

		let Europe = [],
			Africa = [],
			America = [],
			Asia = [],
			Oceania = [];

		let currentWinners = winners
			.filter(function(winner){ // ['fencing','gold','fr']
				return winner[0] === sportName;
			})
			.forEach(function(winner){ // ['fencing', 'gold', 'fr']
				let winnerCountry = winner[2];
				let winnerContinent = getContinentByCountry(winnerCountry);

				winner = `<div class="${winner[1]}">${getIconForMedal(winner[1])} - ${winner[2]}</div>`;

				switch(winnerContinent){
					case 'Europe':
						Europe.push(winner);
						break;
					case 'Africa':
						Africa.push(winner);
						break;
					case 'The Americas':
						America.push(winner);
						break;
					case 'Asia':
						Asia.push(winner);
						break;
					case 'Oceania':
						Oceania.push(winner);
						break;
				}
			})

		console.log(currentWinners);

		return `<tr>
			<td>${sportIcon}</td>
			<td>${Europe.join('')}</td>
			<td>${Africa.join('')}</td>
			<td>${America.join('')}</td>
			<td>${Asia.join('')}</td>
			<td>${Oceania.join('')}</td>
		</tr>`;
	})
	.join('')

// console.log(TRs);

document.write(`<table>
	<thead>
		<tr>
			<th></th>
			${THs}
		</tr>
	</thead>
	<tbody>
		${TRs}
	</tbody>
</table>`);

