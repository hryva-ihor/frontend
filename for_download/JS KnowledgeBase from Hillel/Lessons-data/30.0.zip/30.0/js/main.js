// import {x, y} from "./variables.js";
// import * as variables from "./variables.js";

// console.log(variables);

// variables.x++;

// console.log(variables.x, variables.y, variables.animals);

// variables.animals[0] = "hello";

// console.log(variables.animals);

// console.log(x, y);

// let myX = x;
// myX++;
// console.log(myX);

// import {x as myX, y as myY} from "./variables.js";

// console.log(myX, myY);

let x = 1000;

import {foo, controller, encode, decode} from "./variables.js";
import * as Variables from "./variables.js";
import Student from "./Student.js";

import User from "./User.js";

console.log(x);
console.log(Variables.x);

console.log( foo(10) );

controller(`https://61e82124e32cd90017acc07e.mockapi.io/users`)
	.then(
		data => console.log(data)
	);


let Ilya = new Student(`Ilya`);
console.log(Ilya);
console.log(Ilya.sayHi());

let Anna = new User(`Anna`);
console.log(Anna);


let encodedText = encode('hello');
console.log(encodedText);

let decodedText = decode(encodedText);
console.log(decodedText);










