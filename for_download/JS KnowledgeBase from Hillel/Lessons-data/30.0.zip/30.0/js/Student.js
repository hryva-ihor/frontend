import User from "./User.js";

export default class Student extends User{
	constructor(name){
		super();
		this.name = name;
	}

	sayHi(){
		return `${super.sayHi()} I'm student!`
	}
}