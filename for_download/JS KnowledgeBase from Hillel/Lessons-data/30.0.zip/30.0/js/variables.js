export let x = 10, y = 20, animals = ["cat", "dog"];

// export function foo(x){
// 	return Math.pow(x,3);
// }

export const foo = x => Math.pow(x,3);

export const controller = async (url, method="GET", obj) => {

	let options = {
		method: method,
		headers: {
			"content-type": "application/json"
		}
	}

	if(obj)
		options.body = JSON.stringify(obj);

	let request = await fetch(url, options);

	if(request.ok){
		return request.json();
	} else{
		throw new Error(request.statusText);
	}
}

export const encode = str => btoa( addSymbolsToString(str, "!!!") );

export const decode = str => atob(str);

const addSymbolsToString = (str, symbol) => str+symbol;