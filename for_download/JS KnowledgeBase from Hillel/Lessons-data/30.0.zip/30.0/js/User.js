export default class User{
	constructor(country){
		this.country = "Ukraine"
	}

	sayHi(){
		return `Hi, ${this.name}!`
	}
}
