document.addEventListener('DOMContentLoaded', function(){

	let btn = document.querySelector(`button`);
	if(btn){
		btn.addEventListener(`click`, () =>  console.log('click'));
	}

});