// line = "------";
// console.log(line);

// x = 10;
// xTwo = Math.pow(x,3);
// xTwo = x*x*x;
// xTwo = x**3;

// console.log(x, xTwo);

// r = 10;
// h = 20;

// S = Math.PI * Math.pow(r,2);
// V = S * h;

// console.log("Radius =", r, "Height =", h, "S = ", S, "V = ", V);

// x = 10;
// y = "20";

// console.log("Radius = " + r + ". S = "+S+". V = "+V+".");

// // Radius = 10.

// document.write(10);
// document.write('<p style="color: red">'+
// 	'<b class="hello">hello</b>'+
// 	'<span class="hello">hello</span>'+
// '</p>');

// oneVariable = `One`;
// x = 10;
// y = 20;
// example = 'result';

//result: 30;

// document.write(`<table border="1" style='table'>
// 	<thead>
// 		<tr>
// 			<th>${oneVariable}</th>
// 			<th>First</th>
// 		</tr>
// 	</thead>
// 	<tbody>
// 		<tr>
// 			<td>${10+20+30}</td>
// 			<td>${example}: ${x+y}</td>
// 		</tr>
// 	</tbody>
// </table>`);

// r = 10;
// h = 20;

// S = Math.PI * Math.pow(r,2);
// V = S * h;

// line = `-----`;

// console.log(`${line}
// 	R = ${r}, H = ${h}. S = ${S}, V = ${V}.
// ${line}`);

// alert, prompt, confirm

// console.log('start');
// alert(`Good morning!`);
// console.log(`end`);

// x = parseInt( prompt(`Enter number`) ); // '10'
// sum = x+20;
// console.log(sum);

// text = prompt(`Enter text`);
// color = prompt(`Enter color, hex`); //'red' => NaN;
// console.log(color);

// x = parseInt(prompt(`Number`));
// sum = x+10;

// document.write(`<h3 style="color: #${color}">${text}, ${sum}</h3>`);

// x = +(prompt(`Enter`));
// console.log(x);

// S = +234.345345345.toFixed(2);
// console.log(S);


// name = prompt(`Enter name`, `John`);
// console.log(name);

// sum = 10+name;
// console.log(sum);

// r = prompt(`Enter r`, 10); //'10'
// h = prompt(`Enter h`, 20);
// console.log(r,h);

// // r = +r;
// // h = +h;

// sum = +r + +h;
// console.log(sum);

// console.log(r+h);

// x = "10";
// console.log(20+x);
// console.log(20-x);
// console.log(20*x);
// console.log(20/x);

// r = +prompt(`Enter r`, 10); //'10'
// h = +prompt(`Enter h`, 20);

// S = Math.PI * r*r;
// console.log(S);

// result = 20*'30'+'100'*2;
// console.log(result); //600100

//r = parseInt(prompt(`Enter r`)); // 'hello'
// NaN

// x = 30;
// y = 20;

// //debugger;

// if(x<y){
// 	console.log(`Yes, ${x} < ${y}.`);
// 	result = x+y;
// } else {
// 	console.log(`No, ${x} > ${y}.`);
// 	result = x*y;
// }

// console.log(result);

// console.log('after');
// console.log('end');

// String, Number, Boolean - true/false

// x = '10';

// // ==
// // ===

// if(x == 10){
// 	console.log('yes');
// } else{
// 	console.log('no');
// }

// r = +prompt(`Enter r`, 7); //"7"

// >
// <
// >=
// <=

// if(r === 7){
// 	S = Math.pow(r,2) * Math.PI;
// 	console.log(`R = ${r}. S = ${S}.`);
// } else{
// 	console.log(`end.`);
// }

// apple = false;

// >
// <
// >=
// <=
// ==  '7' == 7
// === '7' === 7

// if(apple){
// 	console.log('here');
// }
