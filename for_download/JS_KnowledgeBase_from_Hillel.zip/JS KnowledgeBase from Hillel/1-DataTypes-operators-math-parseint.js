// x = 10;
// y = 20;

// sum = x+y;

// console.log(x);
// console.log(y);
// console.log(sum);

// console.log(x,y,sum); // 10 20 30
// console.log(x+y); // 30

// String, number;

// name = "Hello, world";
// console.log(name);

// x = "ten";
// y = 20;

// console.log("x=", x, "y=", y, "x+y=", x+y);

// x = 10; // string, 0123456789

// //y = Number("19sdf"); // number NaN
// //y = +"19";

// y = parseInt("19"); // number NaN

// console.log(x);
// console.log(y);
// console.log(x+y); //1020

// x = 10;
// y = 20;
// z = 3;
// d = 5;

// console.log( ((x+y)*2 + (z+d)/3)-2 );

// document.write('<h1>+12323423</h1>');

