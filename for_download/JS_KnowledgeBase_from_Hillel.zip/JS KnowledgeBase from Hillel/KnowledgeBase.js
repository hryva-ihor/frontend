// !Link https://docs.google.com/document/u/0/

// ! 1
let f1 = () => {
    // x = 10;
    // y = 20;

    // sum = x+y;

    // console.log(x);
    // console.log(y);
    // console.log(sum);

    // console.log(x,y,sum); // 10 20 30
    // console.log(x+y); // 30

    // String, number;

    // name = "Hello, world";
    // console.log(name);

    // x = "ten";
    // y = 20;

    // console.log("x=", x, "y=", y, "x+y=", x+y);

    // x = 10; // string, 0123456789

    // //y = Number("19sdf"); // number NaN
    // //y = +"19";

    // y = parseInt("19"); // number NaN

    // console.log(x);
    // console.log(y);
    // console.log(x+y); //1020

    // x = 10;
    // y = 20;
    // z = 3;
    // d = 5;

    // console.log( ((x+y)*2 + (z+d)/3)-2 );

    // document.write('<h1>+12323423</h1>');
}
// ! 2
let f2 = () => {
    // line = "------";
    // console.log(line);

    // x = 10;
    // xTwo = Math.pow(x,3);
    // xTwo = x*x*x;
    // xTwo = x**3;

    // console.log(x, xTwo);

    // r = 10;
    // h = 20;

    // S = Math.PI * Math.pow(r,2);
    // V = S * h;

    // console.log("Radius =", r, "Height =", h, "S = ", S, "V = ", V);

    // x = 10;
    // y = "20";

    // console.log("Radius = " + r + ". S = "+S+". V = "+V+".");

    // // Radius = 10.

    // document.write(10);
    // document.write('<p style="color: red">'+
    // 	'<b class="hello">hello</b>'+
    // 	'<span class="hello">hello</span>'+
    // '</p>');

    // oneVariable = `One`;
    // x = 10;
    // y = 20;
    // example = 'result';

    //result: 30;

    // document.write(`<table border="1" style='table'>
    // 	<thead>
    // 		<tr>
    // 			<th>${oneVariable}</th>
    // 			<th>First</th>
    // 		</tr>
    // 	</thead>
    // 	<tbody>
    // 		<tr>
    // 			<td>${10+20+30}</td>
    // 			<td>${example}: ${x+y}</td>
    // 		</tr>
    // 	</tbody>
    // </table>`);

    // r = 10;
    // h = 20;

    // S = Math.PI * Math.pow(r,2);
    // V = S * h;

    // line = `-----`;

    // console.log(`${line}
    // 	R = ${r}, H = ${h}. S = ${S}, V = ${V}.
    // ${line}`);

    // alert, prompt, confirm

    // console.log('start');
    // alert(`Good morning!`);
    // console.log(`end`);

    // x = parseInt( prompt(`Enter number`) ); // '10'
    // sum = x+20;
    // console.log(sum);

    // text = prompt(`Enter text`);
    // color = prompt(`Enter color, hex`); //'red' => NaN;
    // console.log(color);

    // x = parseInt(prompt(`Number`));
    // sum = x+10;

    // document.write(`<h3 style="color: #${color}">${text}, ${sum}</h3>`);

    // x = +(prompt(`Enter`));
    // console.log(x);

    // S = +234.345345345.toFixed(2);
    // console.log(S);


    // name = prompt(`Enter name`, `John`);
    // console.log(name);

    // sum = 10+name;
    // console.log(sum);

    // r = prompt(`Enter r`, 10); //'10'
    // h = prompt(`Enter h`, 20);
    // console.log(r,h);

    // // r = +r;
    // // h = +h;

    // sum = +r + +h;
    // console.log(sum);

    // console.log(r+h);

    // x = "10";
    // console.log(20+x);
    // console.log(20-x);
    // console.log(20*x);
    // console.log(20/x);

    // r = +prompt(`Enter r`, 10); //'10'
    // h = +prompt(`Enter h`, 20);

    // S = Math.PI * r*r;
    // console.log(S);

    // result = 20*'30'+'100'*2;
    // console.log(result); //600100

    //r = parseInt(prompt(`Enter r`)); // 'hello'
    // NaN

    // x = 30;
    // y = 20;

    // //debugger;

    // if(x<y){
    // 	console.log(`Yes, ${x} < ${y}.`);
    // 	result = x+y;
    // } else {
    // 	console.log(`No, ${x} > ${y}.`);
    // 	result = x*y;
    // }

    // console.log(result);

    // console.log('after');
    // console.log('end');

    // String, Number, Boolean - true/false

    // x = '10';

    // // ==
    // // ===

    // if(x == 10){
    // 	console.log('yes');
    // } else{
    // 	console.log('no');
    // }

    // r = +prompt(`Enter r`, 7); //"7"

    // >
    // <
    // >=
    // <=

    // if(r === 7){
    // 	S = Math.pow(r,2) * Math.PI;
    // 	console.log(`R = ${r}. S = ${S}.`);
    // } else{
    // 	console.log(`end.`);
    // }

    // apple = false;

    // >
    // <
    // >=
    // <=
    // ==  '7' == 7
    // === '7' === 7

    // if(apple){
    // 	console.log('here');
    // }
}
// ! 3
let f3 = () => {
    // !

    // x = 10;

    // if(x != '10'){
    // 	console.log('yes, x not 20');
    // }

    // userAnswer = prompt("enter smth NOT yes");

    // if(userAnswer !== 'yes'){
    // 	console.log('ok');
    // }

    // ' ', 'hello', 'a' => true
    // -10,10 => true

    // '' => false
    // 0 => false

    // q1 = prompt("Do you want fruits?").toLowerCase().replaceAll(' ','');

    // console.log(q1);

    // if(q1 === 'yes'){
    // 	console.log('in progress');
    // }

    // name = prompt('Enter name').trim().replaceAll(' ','');
    // console.log(name);

    // if(q1 === 'yes'){
    // 	console.log('in progress');
    // }

    // trim()

    // replace() / replaceAll()

    // toUpperCase() / toLowerCase()

    // x = prompt('Enter value, which >1 and <=10'); // 5

    // if(x>1 && x<=10 && x%2 !== 0){
    // 	console.log('yes');
    // }

    // color = prompt(`Choose: red or blue`); // red

    // if(color==='red' ||  color==='blue' || color==='green'){
    // 	console.log(yes);
    // }

    // name = prompt('Enter name, which not start with a, A'); // Bogdan
    // console.log(name);
    // console.log(name[0]);

    // if(name[0].toLowerCase() !== 'a'){
    // 	console.log('yes', name);
    // }

    // email = prompt('Enter email', 'hello').replaceAll(' ',''); // hello

    // // console.log(email.length);
    // // console.log(email[email.length-1]);

    // if(!email.startsWith('@') && !email.endsWith('@') && email.includes('@')){ // true && true
    // 	console.log('Hello')
    // } else{
    // 	console.log('not valid');
    // }

    // if(email[0] === '@' || email[email.length-1] === '@' || !email.includes('@')){ // false || false || false
    // 	console.log('not valid');
    // } else{
    // 	console.log('Hello')
    // }

    // startsWith/endsWith

    // includes/charAt/indexOf

    // ++

    // sum = 0;
    // apple = 3;

    // // sum = sum+apple;
    // sum += apple;

    // orange = 4;

    // // sum = sum+orange;
    // sum += orange;


    // sum = 0;

    // sum = sum + 1;
    // sum += 1;
    // sum++;
    // ++sum;

    // sum = 0;
    // ++sum;
    // console.log(sum);

    // sum = 10;
    // sum = sum - 1;
    // sum -= 1;
    // sum--;
    // --sum;

    // result = 0;
    // applePrice = 10;

    // result += appleCount*applePrice;
    // result += orangeCount*orangePrice;

    // isNaN

    // result = 0;

    // appleCount = parseInt(prompt('Enter count of apple', 10));
    // console.log(appleCount);

    // if( !isNaN(appleCount) ){
    // 	result += appleCount;
    // }

    // orangeCount = parseInt(prompt('Enter count of orange', 10)); // NaN
    // console.log(orangeCount); // NaN;

    // if(orangeCount>0){
    // 	result += orangeCount;
    // }

    // console.log(`Result = ${result}`);

    // x = '10'; // NaN;
    // console.log( isNaN(x) );

    // year = prompt('Enter year');
    // // '', null, 0

    // if(year && year>0 && !isNaN(year)){
    // 	console.log(`Hello, ${year}`);

    // 	currentDate = new Date();
    // 	currentYear = currentDate.getFullYear();

    // 	age = new Date().getFullYear() - year;

    // 	console.log(age);
    // }


    // age = +prompt('23');

    // if(!isNaN(age)){
    // 	console.log('yes');
    // }

    // 'dfgdfg19sdfsdf'

    // typeof

    // ternars

    // color = 'red';

    // if(color === 'red'){
    // 	console.log('yes');
    // } esle{
    // 	console.log('no');
    // }

    // console.log( color === 'red' ? 'yes' : 'no' );

    // color === 'red' ? console.log('yes') : console.log('no');

    // user = prompt('Enter + or -');
    // color = user === "+" ? "red" : 'black';

    // fruits = prompt('Do you want fruits');

    // fruits === 'yes' ? 
    // 	prompt('Do you want apple') === 'yes' ? console.log('Apple yes') : console.log('Apple no') 
    // 	: prompt('Do you want orange') === 'yes' ? console.log('Orange yes') : console.log('Orange no');


    // вопрос ? да : нет

    // Date – https://learn.javascript.ru/date
}
// ! 4
let f4 = () => {
    // name, null, if/else, ternar

    // userName = prompt(`Enter name`, `Alla Victoria`);
    // userName = !userName ? 'not valid' : userName.trim();
    // console.log(userName);

    // name = prompt(`Enter name`, `Alla Victoria`);
    // name = name==='' || name==='null' ? 'not valid' : name.trim();
    // console.log(name);

    // yearOfBirth = prompt(`Enter year`);
    // age = 0;

    // if(!isNaN(yearOfBirth)){
    // 	age = new Date().getFullYear()-yearOfBirth;
    // }

    // document.write(`<li>Age: ${age}</li>`);
    // console.log('after');

    // userName = prompt('Enter name');

    // if(!userName){
    // 	userName = prompt('Enter name');
    // }

    // console.log(userName);

    //switch/case


    // name = prompt(`Enter name`);

    // switch(name){
    // 	case 'Dima':
    // 	case 'Dmitriy':
    // 		console.log(`No, I'm Dima`);
    // 		break;
    // 	case 'Ivan':
    // 		console.log(`No, I'm Ivan`);
    // 		break;
    // 	case 'Olena':
    // 		console.log(`Yes, I'm Olena`);
    // 		break;
    // 	default:
    // 		console.log(`Smth`);
    // }


    // h1Text = prompt(`Enter text`);
    // h1Text = !h1Text ? 'Smth' : h1Text.trim();

    // h1Color = prompt(`Enter color`);
    // h1Color = !h1Color ? 'red' : h1Color.trim().toLowerCase();

    // switch(h1Color){
    // 	case 'синий':
    // 	case 'блакитний':
    // 		h1Text += `, sky!`;
    // 		h1Color = `blue`;
    // 		break;
    // 	case 'зелений':
    // 		h1Color = 'green';
    // 		break;
    // }

    // document.write(`<h1 style="color: ${h1Color}">${h1Text}</h1>`);

    // confirm

    // color = confirm(`Do you want blakutniy?`);
    // console.log(color);

    // if(color){
    // 	console.log('ok');
    // }

    // prompt/confirm

    // while
    // do/while
    // for

    // userName = prompt(`Enter name`);

    // while(!userName){
    // 	userName = prompt(`Enter name`);
    // }

    // console.log(userName);

    // debugger;

    // x = prompt('Enter x>=5 && x<=10 && x !== 7'); //null
    // //console.log(x);

    // while(x<5 || x>10 || x==7 || x !== null){
    // 	alert(`${x} is not valid, please enter another`);
    // 	x = prompt('Enter x>=5 && x<=10 && x !== 7');
    // 	console.log(x);
    // }

    // console.log(x);

    // do/while

    // report = 'Is not valid';
    // reportShow = false;

    // counter = 4;

    // do{
    // 	if(reportShow){
    // 		alert(report);
    // 		counter--;
    // 	}

    // 	x = prompt('Enter x>=5 && x<=10 && x !== 7');
    // 	if(x<5 || x>10 || x==7){
    // 		reportShow = true;
    // 	}

    // } while(x<5 || x>10 || x==7 || counter>=0)

    // console.log(x);

    // userName = prompt(`Enter name`);

    // while(!userName){
    // 	userName = prompt(`Enter name`);
    // }

    // do{
    // 	userName = prompt(`Enter name`);
    // } while(!userName);

    // console.log(userName);

    // do{}/while
    // while(){}

    // x = -10;

    // do{
    // 	x--;
    // } while(x>=0)

    // x = 8;

    // if(x>=10){
    // 	console.log('yes');
    // 	console.log('smth');
    // }
    // else if(x===9)
    // 	console.log('another yes');
    // 	console.log('9 more');

    // y = 10;
    // do{
    // 	year = parseInt(prompt(`Enter year`));
    // } while(isNaN(year));

    // console.log(year);

    // userName = prompt(`Enter`);

    // document.write(`<ul>
    // 	${userName ? `<li>Name: ${userName}</li>` : ``}
    // </ul>`);

    // x = 10;
    // x = x+1;
    // x+=1;
    // x++;
    // ++x;

    //debugger;

    // x = 1;

    // for(; x>=1 && x<=10 && x%2>0; x++){
    // 	console.log(x); //1
    // }

    // console.log(`Final: ${x}`)

    // x = 10;

    // for(x = 10, y = 1; x>0 && y<=10; x--, y++){
    // 	console.log(x,y);
    // }
}
// ! 5
let f5 = () => {
    // result = 0;

    // q1 = prompt(`...`);
    // q1 = q1 ? q1.trim().toLowerCase() : ``;

    // switch(q1){
    // 	case 'blue':
    // 		result += 10;
    // }

    // q2 = confirm(`...`);

    // if(q2)
    // 	result += 10;

    // result;

    // for

    // for(i=0; i<=10; i++){
    // 	console.log(i);
    // }

    // console.log(`after cycle ${i}`);

    // do{
    // 	a = parseInt(prompt(`Enter a`, 5)); // 5
    // } while(isNaN(a));

    // //console.log(a); // 5

    // do{
    // 	b = parseInt(prompt(`Enter b`, 10)); // 10
    // } while(isNaN(b) || b<=a);

    // //console.log(b); // 3

    // do{
    // 	h = parseInt(prompt(`Enter h`)); // -11
    // } while(isNaN(h) || h<=0);


    // // while(a<=b){
    // // 	console.log(a);
    // // 	a++;
    // // }

    // for(; a<=b; a += h){
    // 	console.log(a);
    // }

    // city = 'saint petersburg new smth';
    // newStr = '';

    // for(i=0; i<city.length; i++){
    // 	//console.log(i, city[i]);
    // 	letter = city[i];

    // 	if(i===0 || city[i-1] === ' '){
    // 		newStr += letter.toUpperCase();
    // 	} else{
    // 		newStr += letter;
    // 	}
    // }

    // console.log(newStr);

    // debugger;

    // for(i=1; i<=10; i++){
    // 	console.log(i);

    // 	if(i === 3){
    // 		break;
    // 	}

    // 	console.log('after if');
    // }

    // debugger;

    // for(i=1; i<=4; i++){
    // 	console.log(i);

    // 	if(i === 3){
    // 		break;
    // 	}

    // 	console.log('after if');
    // }

    // toPoint: for(i=1; i<=5; i++){
    // 	console.log(i);

    // 	for(j=1; j<=i; j++){
    // 		console.log(`	${j}`);

    // 		if(j==3){
    // 			break toPoint;
    // 		}
    // 	}
    // }

    // debugger;

    // toStart: for(i=1; i<=5; i++){
    // 	console.log(i);

    // 	for(j=1; j<=i; j++){
    // 		console.log(`	${j}`);

    // 		if(j==2){
    // 			continue toStart;
    // 		}

    // 		console.log(`****`);
    // 	}

    // 	console.log('in outer func')
    // }

    // break/continue

    // 5

    // // 5%1 = 0
    // 5%2 = 1
    // 5%3 = 1
    // 5%4 = 1
    // // 5%5 = 0

    // 6

    // // 6%1 = 0
    // 6%2 = 0 // is not Prime; break
    // 6%3
    // 6%4
    // 6%5
    // // 6%6 = 0

    // number = 5;
    // isPrime = true;

    // for(i=2; i<number; i++){
    // 	ostatok = number%i;

    // 	console.log(`${number} % ${i} = ${ostatok}`);

    // 	if(ostatok === 0){
    // 		isPrime = false;
    // 		break;
    // 	}
    // }


    // if(isPrime){
    // 	console.log(`${number} is Prime`);
    // } else{
    // 	console.log(`${number} is not Prime`);
    // }

    //console.log(isPrime ? `${number} is Prime` : `${number} is not Prime`);

    // debugger;

    // for(number=1, sumOfPrimes=0; number<=10; number++){

    // 	console.log(`${number}`);

    // 	isPrime = true;

    // 	for(i=2; i<number; i++){
    // 		ostatok = number%i;

    // 		console.log(`	${number} % ${i} = ${ostatok}`);

    // 		if(ostatok === 0){
    // 			isPrime = false;
    // 			break;
    // 		}
    // 	}

    // 	console.log(isPrime ? `${number} is Prime` : `${number} is not Prime`);

    // 	if(isPrime){
    // 		sumOfPrimes += number;
    // 	}

    // }

    // console.log(`Sum of prime numbers = ${sumOfPrimes}`);

    // toStart: for(i=1, sumOfPrimeNumbers=0; i<=10; i++){

    // 	for(j=2; j<i; j++){

    // 		if(i%j === 0){
    // 			continue toStart;
    // 		}

    // 	}

    // 	sumOfPrimeNumbers += i;
    // }

    // console.log(sumOfPrimeNumbers); // 1+2+3

    // for(i=1, sum=0; i<=10; i++){
    // 	console.log(`${i} + ${sum} = ${sum+i}`);
    // 	sum += i;
    // }

    // console.log(sum);

    // for(i=1, multiply=1; i<=10; i++){
    // 	console.log(`${i} * ${multiply} = ${multiply*i}`);
    // 	multiply *= i;
    // }

    // console.log(multiply);

    // 3! = 1*2*3;
    // 5! = 1*2*3*4*5;

    // 1-5

    // 1! + 2! + 3! = sumOfFactorials

    // number = 5;
    // for(i=1, factorial=1; i<=number; i++){
    // 	factorial *= i;
    // }

    // console.log(`${number}! = ${factorial}`);

    // Array


    // student = 'Artem';
    // age = 13;

    // student_2 = 'Olenka'
    // age_2 = 14;

    // names = ['Artem', 'Olenka'];
    // ages = [13, 14];

    //console.log(x);

    // animals = ['cat','dog','lion',12,true,,'hello'];
    // console.log(animals);

    // animals[0] = 'lion';
    // animals[5] = 'NEW';

    // console.log( animals.indexOf('lion') );

    // animals[7] = 100;
    // animals[animals.length] = 200;

    // animals[50] = 'fifty';
    // animals[animals.length] = 'sixty';

    // console.log(animals);

    // cat = animals[0];
    // console.log( cat );

    // console.log(animals[5]);


    // numbers = [10,20,30,40,50]; //5

    // for(i=0; i<numbers.length; i++) {
    // 	item = numbers[i];
    // 	item *= 2;

    // 	numbers[i] = item;
    // }

    // console.log(numbers);

    // console.log(numbers);

    // console.log(numbers.length);

    // numbers.length = 3;
    // console.log(numbers);

    animals = ['cat', 'dog', 23, true, , 'lion', 100];

    document.write(`<ul>`);

    for (i = 0; i < animals.length; i++) {
        if (typeof animals[i] === 'string')
            document.write(`<li>${animals[i]}</li>`);
    }

    document.write(`</ul>`);

    // Math.random()

    // Math.floor()
    // Math.ceil()
    // Math.round()
}
// ! 6
let f6 = () => {
    // 5-10.
    // 5
    // 6
    // 7
    // 8
    // 9
    // 10

    // for(a=5, b=10; a<=b; a += 1){
    //     console.log(a); //6
    // }

    // arr = [10,20,30,40,50];
    //        // 0  1  2  3  4

    // for(i=0; i<arr.length; i+=4){
    //     //console.log(poryadkovyNomer);
    //     console.log(arr[i]); //10, 50.
    // }

    // 1-10;
    // 1,2,3,5,7

    // toStart: for(i=1; i<=10; i++){
    //     //console.log(i);

    //     for(j=2; j<i; j++){
    //         //console.log(`   ${j}`);
    //         if(i%j === 0){
    //             continue toStart;
    //         }
    //     }

    //     console.log(i);
    // }

    // 5%1 = 0
    // 5%2
    // 5%3
    // 5%4
    // 5%5 = 0

    // Калькулятор
    // 1) С помощью prompt запрашиваем у пользователя что он хочет сделать (+ - / *). Спрашиваем до тех пор, пока он не введет допустимое значение
    // 2) Запрашиваем сколько операндов он хочет использовать. Это должно быть ЧИСЛО больше 1 и меньше 7. Спрашиваем пока пользователь не введет допустимое значение
    // 3) Запрашиваем у пользователя каждый операнд. Это должно быть ЧИСЛО. Запрашиваем пока пользователь не введет допустимое значение
    // 4) С помощью alert или console.log выводим финальный результат действия (+ - / *).

    // do{
    //     znak = prompt(`Enter one of operation +,-,*,/`, `+`); //+
    //     znak = znak ? znak.trim() : ``;
    // } while(znak !== '+' && znak !== '-' && znak !== '*' && znak !== '/');

    // console.log(znak);

    // do{
    //     countOfOperands = +prompt(`Enter count of operands, >1 and <=7`, 5);
    // } while(countOfOperands<=1 || countOfOperands>7);

    // console.log(countOfOperands); // 5


    // for(i=1; i<=countOfOperands; i++){
    //     operand = +prompt(`Enter operand #${i}`);// 10, 20
    //     //console.log(operand);

    //     if(i==1){
    //         result = operand;
    //     } else {
    //         switch(znak){
    //             case '+':
    //                 result += operand;
    //                 break;
    //             case `-`:
    //                 result -= operand;
    //                 break;
    //             case `*`:
    //                 result *= operand;
    //                 break;
    //             case `/`:
    //                 result /= operand;
    //                 break;
    //         }
    //     }
    // }

    // console.log(result);

    // a = 10;
    // b = 20;

    // console.log(result);

    // min = -10;
    // max = 10;
    // Math.floor(Math.random() * (max - min + 1)) + min;

    // arrA = new Array(10);

    // for(i=0, min=-10, max=10; i<arrA.length; i++){
    //     arrA[i] = Math.floor(Math.random() * (max - min + 1)) + min;

    //     if(i===0){
    //         minValue = maxValue = arrA[i];
    //     } else{
    //         if(arrA[i]<minValue){
    //             minValue = arrA[i];
    //         }

    //         if(arrA[i]>maxValue){
    //             maxValue = arrA[i];
    //         }
    //     }
    // }

    // console.log(arrA);
    // console.log(`Min value = ${minValue}`);
    // console.log(`Max value = ${maxValue}`);


    // index

    // arrA = new Array(10);

    // for(i=0, min=-10, max=10, minIndex=maxIndex=0; i<arrA.length; i++){
    //     arrA[i] = Math.floor(Math.random() * (max - min + 1)) + min;

    //     if(arrA[i]<=arrA[minIndex]){
    //         minIndex = i;
    //     }

    //     if(arrA[i]>=arrA[maxIndex]){
    //         maxIndex = i;
    //     }
    // }

    // console.log(arrA);
    // console.log(`Min index = ${minIndex}`); // 6
    // console.log(`Max index = ${maxIndex}`); // 1

    // arrB = [];

    // if(minIndex>maxIndex){
    //     startIndex = maxIndex;
    //     endIndex = minIndex;
    // } else{
    //     startIndex = minIndex;
    //     endIndex = maxIndex;
    // }

    // for(i=0, startIndex+=1; startIndex<endIndex; startIndex++, i++){
    //     arrB[i] = arrA[startIndex];
    // }

    // console.log(arrB);

    // max, min

    // push
    // pop
    // shift
    // unshift
    // reverse
    // join
    // split

    // in range

    // copy

    // spread/rest

    // Math.max();
    // Math.min()
}
// ! 7
let f7 = () => {
    // Array

    //trafficLights

    // circles = [];
    // colors = ['red', 'yellow', 'green', 'purple', 'orange'];

    // for(i=0; i<colors.length; i++){

    // 	// switch(i){
    // 	// 	case 0:
    // 	// 		color = 'red';
    // 	// 		break;
    // 	// 	case 1:
    // 	// 		color = 'yellow';
    // 	// 		break;
    // 	// 	case 2:
    // 	// 		color = 'green';
    // 	// 		break;
    // 	// }

    // 	circles[circles.length] = `<span class="circle" style="background: ${colors[i]}"></span>`;
    // }

    // console.log(circles);

    // document.write(`<div class="trafficLights">${ circles.join('') }</div>`);

    // cycle

    // myArr = [];
    // sum = 0;

    // for(i=10; i<13; i++){
    // 	// myArr[myArr.length] = i;
    // 	sum += i;
    // }

    // console.log(sum);

    // animals

    // animalsIcons = ['🐶', '🐱', '🐹', '🐰', '🦊', '🐻'];
    // animalsNames = ['dog', 'cat', 'mouse', 'rabbit'];

    // trs = [];

    // arrToWork = animalsIcons.length>animalsNames.length ? animalsNames : animalsIcons;

    // for(i=0; i<arrToWork.length; i++){

    // 	firstLetter = animalsNames[i][0].toUpperCase();
    // 	// name = firstLetter + animalsNames[i].slice(1, animalsNames[i].length)
    // 	name = firstLetter + animalsNames[i].slice(1);

    // 	trs[trs.length] = `<tr>
    // 		<td>${name}</td>
    // 		<td>${animalsIcons[i]}</td>
    // 	</tr>`;

    // 	//animalsNames[i] === 'cat' ? alert('hello') : console.log('hello');
    // }

    // document.write(`<table border="1">
    // 	${trs.join('')}
    // </table>`);

    // str = 'Hillel';
    // newStr = str.slice(-3); // lle
    // console.log(newStr);

    // product

    // vegetables = ['cabbage','avocado','tomato'];
    // vegetablesPrice = [8,30,10];

    vegetables = [
        ['cabbage', 8],
        ['avocado', 30],
        ['tomato', 10],
    ];

    // vegetablesNames = '';
    // for(i=0; i<vegetables.length; i++){
    // 	vegetablesNames += vegetables[i][0];

    // 	if(i !== vegetables.length-1){
    // 		vegetablesNames += ', ';
    // 	}
    // }

    // vegetablesNames = [];
    // for(i=0; i<vegetables.length; i++){
    // 	vegetablesNames[vegetablesNames.length] = vegetables[i][0];
    // }

    // vegetablesNamesStr = vegetablesNames.join(`, `);
    // console.log(vegetablesNamesStr);

    // fruits = [
    // 	['grapes', 20],
    // 	['raspberry', 25],
    // 	['coconut', 50],
    // ];

    // fruitsNames = [];
    // for(i=0; i<fruits.length; i++){
    // 	fruitsNames[fruitsNames.length] = fruits[i][0];
    // }

    // fruitsNamesStr = fruitsNames.join(`, `);
    // console.log(fruitsNamesStr);

    // season = [
    // 	['avocado', 30],
    // 	['raspberry', 25],
    // ];

    // koef = 2;

    // type = confirm(`Do you want vegetables?`);

    // if(type){
    // 	do{
    // 		product = prompt(`Select ${vegetablesNamesStr}`, vegetablesNames[0]);
    // 		product = product ? product.trim().toLowerCase() : ``;

    // 	} while(vegetablesNames.indexOf(product)===-1);


    // 	for(i=0; i<vegetables.length; i++){
    // 		if(vegetables[i][0] === product){
    // 			price = vegetables[i][1];
    // 			break;
    // 		}
    // 	}

    // } else{
    // 	do{
    // 		product = prompt(`Select ${fruitsNamesStr}`, fruitsNames[0]);
    // 		product = product ? product.trim().toLowerCase() : ``;

    // 	} while(fruitsNames.indexOf(product)===-1);

    // 	for(i=0; i<fruits.length; i++){
    // 		if(fruits[i][0] === product){
    // 			price = fruits[i][1];
    // 			break;
    // 		}
    // 	}
    // }

    // currentMonth = new Date().getMonth();
    // winterSeason = currentMonth === 0 || currentMonth === 1 || currentMonth === 11 ? true : false;

    // if(winterSeason){
    // 	for(i=0; i<season.length; i++){
    // 		if(season[i][0] === product){
    // 			price *= koef;
    // 			break;
    // 		}
    // 	}
    // }

    // console.log(`Your product is ${product} and cost $${price}`);

    // CHESS BOARD

    TRS = [];
    alphabet = `abcdefgh`;
    figures = [`rook`, `horse`, `bishop`, `queen`, `king`, `bishop`, `horse`, `rook`];

    for (trIndex = 9; trIndex >= 0; trIndex--) {

        value = '';

        color = trIndex === 1 || trIndex === 2 ? `black` : `white`;

        TDS = [];
        for (tdIndex = 0; tdIndex <= 9; tdIndex++) {

            if (trIndex > 0 && trIndex < 9) {
                if (tdIndex === 0 || tdIndex === 9) {
                    value = trIndex;
                } else {
                    value = ``
                }
            } else {
                if (tdIndex > 0 && tdIndex < 9) {
                    value = alphabet[tdIndex - 1];
                } else {
                    value = '';
                }
            }

            if (trIndex === 2 || trIndex === 7) {
                if (tdIndex > 0 && tdIndex < 9) {
                    value = `<img src="images/chess/${color}/pawn.svg" width="40" height="40">`;
                }
            }

            if (trIndex === 1 || trIndex === 8) {
                if (tdIndex > 0 && tdIndex < 9) {
                    value = `<img src="images/chess/${color}/${figures[tdIndex - 1]}.svg" width="40" height="40">`;
                }
            }

            TDS[TDS.length] = `<td>${value}</td>`;
        }

        TRS[TRS.length] = `<tr>${TDS.join('')}</tr>`;
    }

    console.log(TRS);


    document.write(`<table>${TRS.join('')}</table>`);
}
// ! 8
let f8 = () => {
    // TRS = [];
    // flowers = ['cherry-blossom','iris','pink-cosmos','sunflower']

    // for(tr=0; tr<=9; tr++){

    //     TDS = [];
    //     for(td=0; td<=9; td++){
    //         if(tr === 0 || tr === 9 || td === 0 || td === 9){
    //             value = `<img src="images/sprout.png">`;
    //         } else if(tr === 1 || tr === 8 || td === 1 || td === 8){
    //             randomFlower = flowers[Math.floor(Math.random() * (flowers.length))];
    //             value = `<img src="images/flowers/${randomFlower}.png">`;
    //         } else if(tr>1 && tr<8 && (tr===td || td===9-tr) ){
    //             value = `<img src="images/mushroom.png">`;
    //         } else{
    //             value = ``;
    //         }

    //         tdTag = `<td>${value}</td>`;
    //         TDS[TDS.length] = tdTag;
    //     }

    //     trTag = `<tr>${TDS.join(``)}</tr>`;
    //     TRS[TRS.length] = trTag;
    // }

    // document.write(`<table>${TRS.join(``)}</table>`);

    // deep copy of array

    // arr = [1,2,3];

    // arr_2 = arr;

    // arr_3 = arr_2;

    // arr_3[0] = 100;

    // console.log(arr);
    // console.log(arr_2);
    // console.log(arr_3);

    // arr_1 = [10,20,30];
    // arr_2 = []; // 1

    // for(i=0; i<arr_1.length; i++){
    //     arr_2[arr_2.length] = arr_1[i];
    // }

    // arr_2[0] = 100;

    // console.log(arr_1);
    // console.log(arr_2);

    // arr = [
    //     10,
    //     [10,20,30],
    //     [40,50,60],
    // ];

    // arr_2 = [];

    // // debugger;

    // for(i=0; i<arr.length; i++){
    //     if(Array.isArray(arr[i])){
    //         newInnerArray = [];
    //         currentArr = arr[i]; // [10,20,30]

    //         for(j=0; j<currentArr.length; j++){
    //             newInnerArray[newInnerArray.length] = currentArr[j];
    //         }

    //         arr_2[arr_2.length] = newInnerArray;
    //     } else{
    //         arr_2[arr_2.length] = arr[i];
    //     }
    // }

    // console.log(arr);
    // console.log(arr_2);

    // arr_2[0] = 100;
    // arr_2[1][0] = 100;

    // push

    // arr = [10,20,30];
    // arr[arr.length] = 40;

    // console.log(arr);

    // arr.push(50);
    // arr.push(50, 60, true, 'hello');

    // newElement = [50, 60, true, 'hello'];
    // for(i=0; i<newElement.length; i++){
    //     arr[arr.length] = newElement[i];
    // }

    // arr = [10,20,30];
    // console.log(arr);

    //console.log( arr.push(49,50,'hello') ); 

    // arr.unshift(100,'hello');
    // console.log( arr.unshift(600) );

    // arr = [10,20,30];
    // arr.pop();

    // console.log( arr.pop() );

    // console.log(arr);

    // arr.shift();

    // console.log(arr);
    // console.log(arr.shift());

    // push/unshift
    // pop/shift

    // reverse

    // arr = [1,2,3,4,5,6,7];
    // console.log(arr);

    // arr.reverse();

    // concat

    // arr_1 = [['cat','dog'],2,3];
    // arr_2 = [4,5,6];
    // arr_100 = ['new',true]

    // arr_3 = arr_1.concat(arr_2, arr_100);

    // console.log(arr_3);

    // arr_3[0][0] = 'lion';

    // console.log(arr_1);

    // arr_1 = [[1,2,3]];
    // arr_2 = [[4,5,6]];

    // arr_3 = arr_1[0].concat(arr_2[0]);

    // console.log(arr_3);

    // arr_3[0] = 100;

    // console.log(arr_1);

    // slice

    // arr = [10,['cat','dog'],30,40,50,60];

    // arr_2 = arr.slice(1,3); // ['cat','dog'],30

    // console.log(arr);
    // console.log(arr_2);

    // arr_2[0][0] = 'LION';

    // arr = [1,2,3,4];

    // arr_2 = arr.slice(-3);

    // console.log(arr_2);


    // arr = [
    //     10,
    //     [1,2,3],
    //     [4,5,6],
    //     'hello'
    // ];

    // arr_2 = [];

    // for(i=0; i<arr.length; i++){
    //     if(Array.isArray(arr[i])){
    //         arr_2.push(arr[i].slice());
    //     } else{
    //         arr_2.push(arr[i]);
    //     }
    // }

    // console.log(arr);
    // console.log(arr_2);

    // arr_2[2][1] = 500;


    // splice

    // arr = [10,20,30,40,50,60]; // 6

    // arr_2 = arr
    //     .slice(1,arr.length-1) // [20,30,40,50]
    //     .slice(-2) 
    //     // .splice(2,1,'hello')// [20,30,'hello',40,50]

    // console.log(arr_2);
    // console.log(arr);

    // indexOf

    // arr = [10,20,30,40,50];
    // console.log(arr.indexOf(100));

    // join

    // arr = [
    //     [10,20,30, [10,20,30, [10,20,30]]],
    //     [40,50,60]
    // ];
    // str = arr.join(', ');

    // console.log(str);

    // split

    // str = '10,    20, a    30'.replaceAll(' ','');
    // arr = str.split('a')
    // console.log(arr);

    // spread/rest
    // http://jsraccoon.ru/es6-spread-rest


    // colors = ['red','green','blue'];
    // rainbow = ['black',...colors,'orange','white'];

    // // // for(i=0; i<rainbow.length; i++){
    // // //     if(i===1){
    // // //         for(j=0; j<colors.reverse().length; j++){
    // // //             rainbow.splice(i,0,colors[j]);
    // // //         }
    // // //     }
    // // // }


    // // console.log(colors);
    // console.log(rainbow);

    // // colors = ['red','green','blue'];

    // arr_2 = '...colors';
    // // arr_2 = colors.slice();

    // console.log(arr_2);


    // Math.max()/Math.min()


    arr = [10, 100, 2, 45, 6, 5];
    console.log(Math.max(...[20, 45, 56, 3]));

    // Императивное и декларативное программирование – https://tproger.ru/translations/imperative-declarative-programming-concepts/

    // Function
    // ! 8
    // ! 9
    // Function

    // debugger;

    // function sayHi(){
    // 	// debugger;
    // 	sum = Math.floor(Math.random()*10) * 2;
    // 	console.log(sum);
    // }

    // countOfFuncCall = +prompt(`Eneter count of function call`, 3);

    // for(i=1; i<=countOfFuncCall; i++){
    // 	sayHi();
    // 	//console.log(10);
    // }

    // sayHi();
    // sayHi();
    // sayHi();
    // sayHi();

    // console.log(sum);

    // function sayHi(userName='Simba', age, country="Ukraine"){
    // 	nameStr = `Hello, ${userName}`;
    // 	ageStr = !age ? `` : `I'm ${age} years old`;
    // 	countryStr = `I'm from ${country}`;

    // 	data = [];
    // 	data.push(nameStr);

    // 	// if(ageStr){
    // 	// 	data.push(ageStr);
    // 	// }
    // 	ageStr && data.push(ageStr);

    // 	data.push(countryStr);

    // 	console.log(data.join(`. `));
    // }

    // sayHi('Artem', 13);
    // sayHi(100, 'Nina');
    // sayHi(undefined,undefined,'Poland');
    // sayHi(undefined,200);

    // console.log(userName);

    // animalType = ['cat','dog'];
    // animalName = ['Murka','Strelka'];

    // function animalSet(types=animalType, names=animalName){
    // 	for(i=0; i<types.length; i++){
    // 		console.log(`${types[i]} ${names[i]}`);
    // 	}
    // }

    // animalSet();

    // animalNamesSecond = ['Mufasa','Red'];
    // animalSet(['lion','fox'], animalNamesSecond);

    // x = 10;

    // function foo(){
    // 	var x = 100;
    // 	x *= 2;
    // 	console.log(`in function`, x); // 600
    // }

    // foo();
    // foo();

    // console.log(`after function`, x); // not defined

    // x = 10;

    // if(true){
    // 	var x = 300;
    // }

    // console.log(x); // 300

    // x = 'hello'

    // function animal(){
    // 	let x = 10;
    // }

    // function human(){
    // 	let x = 100;
    // }

    // animal();
    // human();

    // console.log(x);

    // if(){}
    // for(){}
    // while(){}

    // let x; // undefined

    // x = 10;

    // function foo(){
    // 	let x = 100;
    // 	console.log(`in function ${x}`); // 100
    // }

    // foo();

    // console.log(`after function ${x}`); // 10

    // let x = 10;

    // if(true){
    // 	let x = 300;

    // 	if(true){
    // 		let y = 400;
    // 	}
    // }

    // console.log(x); // 300
    // for(let i=0; i<=10; i++){

    // }

    // console.log(i); // not defined

    // for(let i=0; i<=10; i++){

    // }

    // 1-10

    // let sum = 0;

    // for(let i=1; i<=10; i++){
    // 	sum += i;
    // }

    // console.log(sum);
    // const ADMIN = 1;
    // const passwords = [ADMIN,2,3];

    // Lexical environment, scopes

    // debugger;

    // let x = 10; // Script

    // function foo(x){ // Local
    // 	let y = 10;
    // 	console.log(x,y);
    // }

    // foo(100);

    // function foo2(a){ // Local
    // 	let b = 10;
    // 	console.log(a,b);
    // }

    // foo2(100);

    // debugger;

    // let x = 10; // Script

    // function first(x){ // LE = x=100, second
    // 	second(x);
    // 	console.log(`in first function, ${x}`);
    // }
    // first(100);

    // function second(){
    // 	console.log(`in second function, ${x}`); // 100, LE = x = 100
    // }

    // console.log(`in global scope, ${x}`);

    // hoisting

    // let y = 'hello';

    // function first(y){
    // 	let x = 10;

    // 	second();
    // }

    // first(30);

    // function second(){
    // 	let x = 20;

    // 	function third(){
    // 		console.log(x, y);
    // 	}

    // 	third();
    // }


    // var/let/const

    //debugger;

    // let x = 100;
    // let z = 'hello';

    // function first(x=10){ // 100
    // 	x += 200;

    // 	function second(){
    // 		x *= 20;
    // 		z += `!`;

    // 		console.log(`in second ${x}`);
    // 	}

    // 	second();

    // 	console.log(`in first ${x}`);
    // }

    // first();

    // console.log(`after function ${x}`);

    // closure

    //debugger;

    // function first(){
    // 	let x = 10;

    // 	function second(){
    // 		x += 100;

    // 		function third(){
    // 			x += 200;
    // 			console.log(`in third ${x}`);
    // 		}

    // 		third();

    // 		console.log(`in second ${x}`);
    // 	}

    // 	second();
    // 	console.log(`in first ${x}`);
    // }

    // first();

    // console.log(`after ${x}`); // not defined

    //debugger;

    function foo(a, b, c, returnMult) {
        let sum = a + b + c;
        let multiply = sum * 10;
        let diff = multiply / 100;

        // if(returnMult){
        // 	return multiply;
        // } else{
        // 	return diff;
        // }

        return returnMult ? multiply : diff;
    }

    // let resultFoo = foo(10,20,30,true);
    // console.log(resultFoo);

    console.log(foo(10, 20, 30, true));
    console.log(foo(10, 20, 30));
}
// ! 9
let f9 = () => {
    // Function

    // debugger;

    // function sayHi(){
    // 	// debugger;
    // 	sum = Math.floor(Math.random()*10) * 2;
    // 	console.log(sum);
    // }

    // countOfFuncCall = +prompt(`Eneter count of function call`, 3);

    // for(i=1; i<=countOfFuncCall; i++){
    // 	sayHi();
    // 	//console.log(10);
    // }

    // sayHi();
    // sayHi();
    // sayHi();
    // sayHi();

    // console.log(sum);

    // function sayHi(userName='Simba', age, country="Ukraine"){
    // 	nameStr = `Hello, ${userName}`;
    // 	ageStr = !age ? `` : `I'm ${age} years old`;
    // 	countryStr = `I'm from ${country}`;

    // 	data = [];
    // 	data.push(nameStr);

    // 	// if(ageStr){
    // 	// 	data.push(ageStr);
    // 	// }
    // 	ageStr && data.push(ageStr);

    // 	data.push(countryStr);

    // 	console.log(data.join(`. `));
    // }

    // sayHi('Artem', 13);
    // sayHi(100, 'Nina');
    // sayHi(undefined,undefined,'Poland');
    // sayHi(undefined,200);

    // console.log(userName);

    // animalType = ['cat','dog'];
    // animalName = ['Murka','Strelka'];

    // function animalSet(types=animalType, names=animalName){
    // 	for(i=0; i<types.length; i++){
    // 		console.log(`${types[i]} ${names[i]}`);
    // 	}
    // }

    // animalSet();

    // animalNamesSecond = ['Mufasa','Red'];
    // animalSet(['lion','fox'], animalNamesSecond);

    // x = 10;

    // function foo(){
    // 	var x = 100;
    // 	x *= 2;
    // 	console.log(`in function`, x); // 600
    // }

    // foo();
    // foo();

    // console.log(`after function`, x); // not defined

    // x = 10;

    // if(true){
    // 	var x = 300;
    // }

    // console.log(x); // 300

    // x = 'hello'

    // function animal(){
    // 	let x = 10;
    // }

    // function human(){
    // 	let x = 100;
    // }

    // animal();
    // human();

    // console.log(x);

    // if(){}
    // for(){}
    // while(){}

    // let x; // undefined

    // x = 10;

    // function foo(){
    // 	let x = 100;
    // 	console.log(`in function ${x}`); // 100
    // }

    // foo();

    // console.log(`after function ${x}`); // 10

    // let x = 10;

    // if(true){
    // 	let x = 300;

    // 	if(true){
    // 		let y = 400;
    // 	}
    // }

    // console.log(x); // 300
    // for(let i=0; i<=10; i++){

    // }

    // console.log(i); // not defined

    // for(let i=0; i<=10; i++){

    // }

    // 1-10

    // let sum = 0;

    // for(let i=1; i<=10; i++){
    // 	sum += i;
    // }

    // console.log(sum);
    // const ADMIN = 1;
    // const passwords = [ADMIN,2,3];

    // Lexical environment, scopes

    // debugger;

    // let x = 10; // Script

    // function foo(x){ // Local
    // 	let y = 10;
    // 	console.log(x,y);
    // }

    // foo(100);

    // function foo2(a){ // Local
    // 	let b = 10;
    // 	console.log(a,b);
    // }

    // foo2(100);

    // debugger;

    // let x = 10; // Script

    // function first(x){ // LE = x=100, second
    // 	second(x);
    // 	console.log(`in first function, ${x}`);
    // }
    // first(100);

    // function second(){
    // 	console.log(`in second function, ${x}`); // 100, LE = x = 100
    // }

    // console.log(`in global scope, ${x}`);

    // hoisting

    // let y = 'hello';

    // function first(y){
    // 	let x = 10;

    // 	second();
    // }

    // first(30);

    // function second(){
    // 	let x = 20;

    // 	function third(){
    // 		console.log(x, y);
    // 	}

    // 	third();
    // }


    // var/let/const

    //debugger;

    // let x = 100;
    // let z = 'hello';

    // function first(x=10){ // 100
    // 	x += 200;

    // 	function second(){
    // 		x *= 20;
    // 		z += `!`;

    // 		console.log(`in second ${x}`);
    // 	}

    // 	second();

    // 	console.log(`in first ${x}`);
    // }

    // first();

    // console.log(`after function ${x}`);

    // closure

    //debugger;

    // function first(){
    // 	let x = 10;

    // 	function second(){
    // 		x += 100;

    // 		function third(){
    // 			x += 200;
    // 			console.log(`in third ${x}`);
    // 		}

    // 		third();

    // 		console.log(`in second ${x}`);
    // 	}

    // 	second();
    // 	console.log(`in first ${x}`);
    // }

    // first();

    // console.log(`after ${x}`); // not defined

    //debugger;

    function foo(a, b, c, returnMult) {
        let sum = a + b + c;
        let multiply = sum * 10;
        let diff = multiply / 100;

        // if(returnMult){
        // 	return multiply;
        // } else{
        // 	return diff;
        // }

        return returnMult ? multiply : diff;
    }

    // let resultFoo = foo(10,20,30,true);
    // console.log(resultFoo);

    console.log(foo(10, 20, 30, true));
    console.log(foo(10, 20, 30));

}
// ! 10
let f10 = () => {
    // let list = [
    // 	[1,2,3],
    // 	[4,5,6]
    // ];

    // function copiedArr(arr){
    // 	let newArr = [];
    // 	for(let i=0; i<arr.length; i++){
    // 		if(Array.isArray(arr[i])){
    // 			newArr.push(arr[i].slice())
    // 		} else{
    // 			newArr.push(arr[i]);
    // 		}
    // 	}

    // 	return newArr;
    // }

    // function modify(arr, value){

    // 	let localArr = copiedArr(arr);

    // 	for(let i=0; i<localArr.length; i++){
    // 		let currentArr = localArr[i]; // [1,2,3]

    // 		for(let j=0; j<currentArr.length; j++){
    // 			currentArr[j] *= value;
    // 		}
    // 	}

    // 	return localArr;
    // }

    // let modifiedArr = modify(list, 2);

    // console.log(list);
    // console.log(modifiedArr);

    // let animals = ['cat','dog','lion'];

    // function renderTable(arr){

    // 	let TRs = [];

    // 	for(let i=0; i<arr.length; i++){
    // 		let tr = `<tr><td>${arr[i]}</td></tr>`;
    // 		TRs.push(tr);
    // 	}

    // 	console.log(TRs);
    // 	console.log(TRs.join(`\n`));

    // 	return `<table>${TRs.join(``)}</table>`;
    // }

    // document.write( renderTable(animals) );

    // let winter = [-7,-3];
    // let summer = [7,3];
    // let fruits = ['apple','kiwi'];

    // let allItems = winter.concat(summer,fruits);
    // console.log(allItems);

    // let all = [winter,summer,fruits];

    // console.log(all);

    // for(let i=0; i<all.length; i++){
    // 	console.log(all[i]);
    // 	let innerArr = all[i];

    // 	for(let j=0; j<innerArr.length; j++){
    // 		console.log(innerArr[j]);
    // 	}
    // }

    // let all = [
    // 	[winter, 'Winter'],
    // 	[summer, 'Summer'],
    // 	[fruits, 'Fruits']
    // ];

    // for(let i=0; i<all.length; i++){
    // 	let innerArr = all[i]; // [winter, 'Winter'],

    // 	console.log(innerArr[1]);

    // 	for(let j=0; j<innerArr[0].length; j++){
    // 		console.log(`	${innerArr[0][j]}`);
    // 	}
    // }

    // function in function

    // debugger;

    // function foo(value, someFunc){

    // 	if(typeof someFunc === 'function'){
    // 		return someFunc(value);
    // 	} else{
    // 		return value;
    // 	}

    // }

    // function multiply(value){ 
    // 	return value*10; 
    // }

    // function sum(x){
    // 	return x+10;
    // }

    // let result = foo(10, multiply);
    // console.log(result);

    // let result_2 = foo(10, sum);
    // console.log(result_2);

    // let result_3 = foo(10, function(value){ return value+' hello!' });
    // console.log(result_3);

    // function modifyStr(str, firstFunc, secondFunc){

    // 	let result = firstFunc(str);
    // 	let finalResult = secondFunc(result);

    // 	return finalResult;
    // }

    // function sayHello(name){
    // 	return `Hello, ${name}.`;
    // }

    // function countryInfo(str){
    // 	return `${str} I'm from Ukraine.`;
    // }

    // let AnnaInfo = modifyStr(`Anna`, sayHello, countryInfo);
    // console.log(AnnaInfo);

    // `Anna. 20. Ukraine.`
    // `Hello, my name is Anna. I'm 20 years old. I'm from Ukraine.`


    // function userInfo(name, age, country, nameFunc, ageFunc, countryFunc){

    // 	if(typeof nameFunc === 'function'){
    // 		name = nameFunc(name);
    // 	}

    // 	if(typeof ageFunc === 'function'){
    // 		age = ageFunc(age);
    // 	}

    // 	if(typeof countryFunc === 'function'){
    // 		country = countryFunc(country);
    // 	}

    // 	let resultStr = [name, age, country].join(`. `);
    // 	return `${resultStr}.`;
    // }

    // function nameModify(name){
    // 	return `Hello, my name is ${name}`;
    // }

    // function ageModify(age){
    // 	return `I'm ${age} years old`;
    // }

    // function countryModify(country){
    // 	return `I'm from ${country}`;
    // }

    // let AnnaInfo = userInfo(`Anna`,20,`Ukraine`,nameModify,ageModify,countryModify);
    // console.log(AnnaInfo);

    // let IgorInfo = userInfo(`Igor`,25,`Poland`,nameModify,undefined,countryModify);
    // console.log(IgorInfo)

    // function sum(someFunc, ...kotik){

    // 	console.log(kotik);

    // 	//console.log(arguments);

    // 	// let newArr = new Array();
    // 	// for(let i=0; i<arguments.length; i++){
    // 	// 	newArr.push(arguments[i]);
    // 	// }

    // 	// let newArr = [...arguments];
    // 	// console.log(newArr);
    // }

    // let result = sum(function(value){ console.log(value) }, 10,20,30,40);
    // console.log(result);

    // recursion

    // let arr = [
    // 	[1,2,3,[[true,false],'dog']],
    // 	[4,5,6],
    // 	7
    // ];

    // // debugger;

    // function copiedArray(arr){ // [true,false]
    // 	let newArr = [];

    // 	for(let i=0; i<arr.length; i++){
    // 		if(Array.isArray(arr[i])){
    // 			newArr.push( copiedArray(arr[i]) ); // [1,2,3]
    // 		} else{
    // 			newArr.push(arr[i]);
    // 		}
    // 	}

    // 	return newArr;
    // }

    // let copyOfArr = copiedArray(arr);

    // console.log(arr);
    // console.log(copyOfArr);

    // copyOfArr[0][3][0][0] = 'skotik';


    // forEach()
    // filter()
    // map()
    // split(), join()
    // every / some
    // reduce
}
// ! 11
let f11 = () => {

}
// ! 12
let f12 = () => {
    // let arr = [1,1,2,2,3,4,5,6,2,1];

    // let unique = arr
    // 	.filter(function(item, index, arr){
    // 		return arr.indexOf(item) === index;
    // 	});

    // console.log(unique);

    // example

    // 1. find year and add it as last el of arr
    // 2. filter users, that younger then 50
    // 3. print all data

    // const women = [
    // 	['Anna',1990],
    // 	['Inna',2007]
    // ];

    // const men = [
    // 	['Igor',1966],
    // 	['Ivan',1975]
    // ];

    // const currentYear = new Date().getFullYear();

    // const userData = ['Name', 'Year', 'Age'];

    // let users = women
    // 	.concat(men)
    // 	.map(function(woman){
    // 		return woman.slice();
    // 	})
    // 	.map(function(user){
    // 		user.push(currentYear-user[1]);
    // 		return user;
    // 	})
    // 	.filter(function(user){
    // 		return user[2]<=50;
    // 	})
    // 	.map(function(user){
    // 		//console.log(user);
    // 		let userInfoRender = user
    // 			.map(function(userInfo, index){
    // 				return `<p>${userData[index]}: ${userInfo}</p>`;
    // 			})
    // 			.join('');

    // 		return `<li>${userInfoRender}</li>`;
    // 	})
    // 	.join(``);

    // document.write(`<ul>${users}</ul>`);

    // [3,3]


    // flat
    // let arr = [
    // 	[1,2,3, [10,20,30, [40,50,60]]],
    // 	[4,5,6]
    // ];

    // let arrModified = arr
    // 	.flat(Infinity) // [1,2,3, [10,20,30, [40,50,60]], 4,5,6]
    // 	.map(function(item){
    // 		return item*2;
    // 	})

    // console.log(arrModified);

    // every/some

    // let arr = [1,2,3,4,'5'];

    // let arrOfNumbers = arr
    // 	.some(function(item, index, arr){
    // 		return typeof item === 'number';
    // 	})

    // console.log(arrOfNumbers); // true

    // reduce

    // let arr = [10,20,30];

    // let summ = 0;
    // for(let i=0; i<arr.length; i++){
    // 	summ+= arr[i];
    // }
    // console.log(summ);

    // debugger;

    // let summ = arr
    // 	.reduce(
    // 		function(kormashek, item, index, arr){
    // 			return kormashek/item;
    // 		}
    // 	);

    // console.log(summ);

    // [name, price, callories]

    // let products = [
    // 	['potato', 30, 6],
    // 	['tomato', 25, 3],
    // 	['kiwi', 40, 7]
    // ];

    // let reduceResult = products
    // 	.reduce(
    // 		function(karmashek, item, index){
    // 			let price = item[1],
    // 				callories = item[2];

    // 			if(index === 0){
    // 				karmashek.push(price, callories);
    // 			} else{
    // 				karmashek[0] += price;
    // 				karmashek[1] += callories;
    // 			}

    // 			return karmashek;
    // 		}, []
    // 	);

    // console.log(reduceResult);

    // [allPrice, allCallories]

    // olympic

    // object
}

// ! 13
let f13 = () => {
    // Object

    // let user = ['Sasha','Bodgan',13,14];
    // user[100] = 100; // 101

    // let user = {
    // 	name: 'Sasha',
    // 	surname: 'Bodgan',
    // 	mathMark: 13,
    // 	englishMark: 14,
    // 	"year of birth": 1990,
    // 	age: 100
    // }

    // console.log(user);
    // user.name = 'Alexandra';

    // delete user.surname;

    // let user = {
    // 	name: 'Sasha',
    // 	surname: 'Bodgan',
    // };

    // for(let key in user){
    // 	console.log(`${key}: ${user[key]}`); // name: Sasha
    // }

    // arr = [10,20,30,40];
    // console.log(arr);
    // arr.name = 'Anna';

    // for(let key in arr){
    // 	console.log(arr[key]);
    // }

    // console.log('-----');

    // for(let key of arr){
    // 	console.log(key);
    // }

    // function sayHello(){
    // 	return `Hello!`;
    // }

    // let user = {
    // 	name: 'Anna',
    // 	age: 3,
    // 	isGirl: true,
    // 	animals: ['cat','dog'],
    // 	parents: [
    // 		{
    // 			name: 'Ivan',
    // 			age: 40
    // 		},
    // 		{
    // 			name: 'Ivanka',
    // 			age: 39
    // 		}
    // 	],
    // 	getInfo: function(){
    // 		return `Hello!`;
    // 	},
    // 	userHello: sayHello,
    // 	sayHello,
    // 	flower: "rose"
    // }

    // // console.log( user.getInfo() );

    // // console.log(sayHello());

    // console.log( user.getInfo() );
    // console.log(user.sayHello());
    // console.log(user.userHello());

    // function getInfo(animal={}){
    // 	let type = animal.type ? `Type: ${animal.type}. ` : ``;
    // 	let name = animal.name ? `Name: ${animal.name}. ` : ``;

    // 	return [type,name].join(``);
    // }

    // let cat = {
    // 	type: 'cat',
    // 	name: 'Tom',
    // 	getInfo
    // }

    // let mouse = {
    // 	// type: 'mouse',
    // 	name: 'Jerry',
    // 	getInfo
    // }

    // let human = {
    // 	name: 'Inna',
    // 	yearOfBirth: 1990,
    // 	age: new Date().getFullYear()-1990,
    // 	getInfo
    // }

    // console.log( cat.getInfo(cat) );
    // console.log( mouse.getInfo(mouse) );

    // let data = [cat,mouse,human];

    // data
    // 	.forEach(function(obj){
    // 		obj.getInfo && console.log(obj.getInfo(obj));
    // 	})

    // console.log(human.getInfo);

    // false => 0, '', undefined, false
    // true => function, ' ', -10, 10, true

    // if(human.getInfo){
    // 	console.log( human.getInfo() );
    // }

    // human.getInfo && console.log( human.getInfo(human) );

    // function getInfo(){
    // 	console.log(this);
    // 	return `I'm ${this.name}, I'm ${this.age} years old.`;
    // }

    // let user = {
    // 	name: 'Gleb',
    // 	age: 30,
    // 	getInfo
    // }

    // console.log( user.getInfo() );

    // let cat = {
    // 	name: 'Tom',
    // 	age: 7,
    // 	getInfo
    // }

    // console.log( cat.getInfo() );

    // console.log( getInfo() );

    // let cat = {
    // 	name: 'Tom',
    // 	age: 7,
    // 	getName: function(){
    // 		return `My name is ${this.name}.`
    // 	},
    // 	getAge: function(){
    // 		return `I'm ${this.age} years old.`
    // 	},
    // 	getInfo: function(){
    // 		//console.log(this); //cat
    // 		let info = [this.getName(), this.getAge()]; // [`My name is Tom.`, `I'm 7 years old.`];
    // 		return info.join(` `); // `My name is Tom. I'm 7 years old.`
    // 	}
    // }

    // console.log( cat.getName() );
    // console.log( cat.getAge() );
    // console.log( cat.getInfo() );

    // console.log('-----');

    // let lion = {
    // 	name: 'Simba',
    // 	age: 13,
    // 	getName: function(){
    // 		return `My name is ${this.name}.`
    // 	},
    // 	getAge: function(){
    // 		return `I'm ${this.age} years old.`
    // 	},
    // 	getInfo: function(){
    // 		//console.log(this); //cat
    // 		let info = [this.getName(), this.getAge()]; // [`My name is Tom.`, `I'm 7 years old.`];
    // 		return info.join(` `); // `My name is Tom. I'm 7 years old.`
    // 	}
    // }

    // console.log( lion.getName() );
    // console.log( lion.getAge() );
    // console.log( lion.getInfo() );


    // ex 2

    function getName() {
        return `My name is ${this.name}.`
    };
    function getAge() {
        return `I'm ${this.age} years old.`
    };

    function getInfo() {
        //console.log(this); //cat
        let info = [getName.call(this), getAge.call(this)]; // [`My name is Tom.`, `I'm 7 years old.`];
        return info.join(` `); // `My name is Tom. I'm 7 years old.`
    };

    const animalFunctions = [getName, getAge, getInfo];

    let cat = {
        name: 'Tom',
        age: 7,
        animalFunctions
    }

    let lion = {
        name: 'Simba',
        age: 13,
        animalFunctions
    }

    console.log(cat);

    cat.animalFunctions
        .forEach(
            function (singleFunc) {
                console.log(singleFunc.call(cat));
            }
        )

    // prototype

    // this
}
// ! 14
let f14 = () => {
    // let obj_1 = {
    // 	a: {
    // 		cat: {
    // 			name: 'Tom',
    // 			age: 7
    // 		},
    // 		mouse: 'Jerry',
    // 	},
    // 	b: 20,
    // 	c: 30
    // };

    // let obj_2 = {
    // 	b: 50,
    // 	c: 60,
    // 	d: 70,
    // 	j: [10,20,30, [40,50, [60,70, {cat: 'Anfisa'}]]]
    // };

    // console.log(obj_1);
    // console.log(obj_2);

    // function copiedArray(arr){
    // 	let newArr = [];

    // 	for(let key in arr){
    // 		if(Array.isArray(arr[key])){
    // 			newArr[key] = copiedArray(arr[key]);
    // 		} else if(typeof arr[key] === 'object'){
    // 			newArr[key] = copiedObject(arr[key]);
    // 		} else{
    // 			newArr[key] = arr[key];
    // 		}
    // 	}

    // 	return newArr;
    // }

    // function copiedObject(obj){
    // 	let newObj = {};

    // 	for(let key in obj){
    // 		if(Array.isArray(obj[key])){
    // 			newObj[key] = copiedArray(obj[key]);
    // 		} else if(typeof obj[key] === 'object'){
    // 			newObj[key] = copiedObject(obj[key]);
    // 		} else{
    // 			newObj[key] = obj[key];
    // 		}
    // 	}

    // 	return newObj;
    // }

    // function concatObjects(...args){
    // 	//console.log(args);

    // 	let copiedObjects = args
    // 		.map(function(obj){
    // 			return copiedObject(obj);
    // 		}); // [obj_1, obj_2]

    // 	return Object.assign({}, ...copiedObjects);
    // }

    // let resultObj = concatObjects(obj_1, obj_2);
    // console.log(resultObj);

    // resultObj.j[0] = 100;

    // let newObj = {
    // 	// x: 'hello'
    // };

    // let key = prompt('Enter option key'); // x
    // let value = prompt('Enter option value'); // hello

    // newObj[key] = value;
    // console.log(newObj);

    // let obj_3 = {
    // 	a: 10,
    // 	b: 20
    // };

    // let obj_4 = {
    // 	a: 100,
    // 	c: 30
    // };

    // console.log(obj_3);
    // console.log(obj_4);


    // let resultObj = Object.assign({}, obj_3, obj_4);
    // console.log(resultObj);

    // resultObj.a = 200;

    // spread/rest

    // let arr = [1,2,3,4,'hello',true];

    // console.log(1,2,3,4);
    // console.log(...arr);
    // console.log(arr);

    // function foo(...myArr){
    // 	console.log(myArr);
    // }

    // foo(10,20);

    // this

    // function foo(){
    // 	console.log(this); // window
    // }

    // foo();
    // window.foo();

    // let cat = {
    // 	type: 'kotik',
    // 	foo
    // }

    // cat.foo();

    // let dog = {
    // 	type: 'sobachcka',
    // 	dogFunc: foo,
    // 	dogUniqueFunc(){
    // 		console.log('dogUniqueFunc');
    // 	}
    // }

    // dog.dogFunc();
    // dog.dogUniqueFunc();

    // function animalInfo(){
    // 	return `Type: ${this.type}`;
    // }

    // let cat = {
    // 	type: 'kotik',
    // 	// animalInfo
    // 	animalInfo(){
    // 		return `Type: ${this.type}`;
    // 	}
    // }
    // console.log( cat.animalInfo() );

    // let dog = {
    // 	type: 'sobachka',
    // 	// animalInfo
    // 	animalInfo(){
    // 		return `Type: ${this.type}`;
    // 	}
    // }
    // console.log( dog.animalInfo() );

    // let user = {
    // 	name: 'Gleb',
    // 	animalInfo
    // }

    // console.log(user.animalInfo());

    // prototype

    // let user = {
    // 	name: 'Anna',
    // }

    // console.log(user.__proto__);

    // let arr = [1,2,3];

    // console.log(arr.__proto__.__proto__);

    // let x = 3;

    // console.log( x.__proto__.__proto__ );

    // console.log(Array.prototype);
    // console.log(String.prototype);

    Array.prototype.getInfo = function () {
        console.log('hello');
    }

    // if(user.__proto__ === arr.__proto__.__proto__ === x.__proto__.__proto__){
    // 	console.log('equals');
    // }

    // myPush

    //renderList

    // const animals = [
    // 	{
    // 		name: 'dog',
    // 		icon: '🐶'
    // 	},
    // 	{
    // 		name: 'cat',
    // 		icon: '🐱'
    // 	},
    // 	{
    // 		name: 'hamster',
    // 		icon: '🐹'
    // 	},
    // 	{
    // 		name: 'rabbit',
    // 		icon: '🐰'
    // 	}
    // ];

    // const fruits = [
    // 	{
    // 		name: 'apple',
    // 		icon: '🍎'
    // 	},
    // 	{
    // 		name: 'cherries',
    // 		icon: '🍒'
    // 	},
    // 	{
    // 		name: 'grapes',
    // 		icon: '🍇'
    // 	}
    // ];


    // Object.create
}
// ! 15
let f15 = () => {
    // const animals = ['🐶', '🐱', '🐹', '🐰'];

    // const fruits = [
    // 	{
    // 		name: 'apple',
    // 		icon: '🍎'
    // 	},
    // 	{
    // 		name: 'cherries',
    // 		icon: '🍒'
    // 	},
    // 	{
    // 		name: 'grapes',
    // 		icon: '🍇'
    // 	}
    // ];

    // //animals.__proto__.renderList = 'hello';

    // function capitalize(word){ // apple
    // 	let letterFirst = word[0].toUpperCase(); // A
    // 	return `${letterFirst}${word.slice(1)}`; // Apple
    // }

    // function renderObject(item){
    // 	let optionsRender = []; // [`name: apple`, `icon: 🍎`];
    // 	for(let key in item){
    // 		optionsRender.push(`${capitalize(key)}: ${item[key]}.`)
    // 	}
    // 	return optionsRender.join('<br>');
    // }

    // Array.prototype.renderList = function(tagName='ul'){
    // 	let LIs = this
    // 		.map(function(item){
    // 			if(typeof item === "object"){
    // 				return `<li>${renderObject(item)}</li>`;
    // 			} else{
    // 				return `<li>${item}</li>`;
    // 			}
    // 		})
    // 		.join('');

    // 	return `<${tagName}>${LIs}</${tagName}>`;
    // }

    // document.write(animals.renderList());
    // document.write(fruits.renderList('ol'));

    // myPush


    // let arr = [10,20,30];
    // arr.push(40,50);

    // console.log(arr.push(60,70));
    // console.log(arr);

    // Array.prototype.myPush = function(...args){
    // 	//console.log(this); // [10,20,30]
    // 	//console.log(args); // [40,50]

    // 	// let currentArray = this;

    // 	args.forEach(arg => this[this.length] = arg)

    // 	// for(let item of args){ //[40,50]
    // 	// 	this[this.length] = item;
    // 	// }

    // 	return this.length;
    // }

    // arr.myPush(40,50);

    // function sum(a,b){
    // 	return a+b;
    // }

    // const sum = (a,b) => a+b;

    // console.log( sum(10,20) );

    // function sum(a){
    // 	return a+10;
    // }

    // const sum = a => a+10;

    // console.log( sum(10) );

    // function sum(){
    // 	return 10;
    // }

    // const sum = () => 10;

    // console.log( sum() );

    // function sum(a,b){
    // 	console.log(a,b);
    // 	return a+b;
    // }

    // const sum = (a,b) => {
    // 	console.log(a,b);
    // 	return a+b;
    // }

    // const sum = (a,b) => {
    // 	return a+b;
    // }

    // const sum = (a,b) => a+b;

    // console.log( sum(10,20) );

    // function sum(){
    // 	console.log(arguments);
    // 	//return a+b;
    // }

    // const sum = (...args) => {
    // 	console.log(args);
    // }

    // sum(10,20,30,40);

    // function foo(){
    // 	console.log(this);
    // }

    // const foo = () => console.log(this);

    // let cat = {
    // 	type: 'cat',
    // 	foo
    // }

    // cat.foo();

    // let arr = [-10,10,-20,30,true,'hello',100];
    // console.log(arr);

    // // 1. filter number
    // // 2. filter >0
    // // 3. Math.pow(item,2)
    // // 4. console

    // arr
    // 	.filter(item => typeof item === 'number')
    // 	.filter(item => item>0)
    // 	.map(item => Math.pow(item,2))
    // 	.forEach(item => console.log(item))

    // Object.create

    // let Parent = {
    // 	name: 'Aleksandr',
    // 	surname: 'Ivanov',
    // 	country: 'Ukraine',
    // 	getInfo(){
    // 		return `Hello, my name is ${this.name} ${this.surname}. I'm from ${this.country}.`
    // 	}
    // }
    // console.log(Parent);
    // console.log(Parent.getInfo());

    // let Gleb = Object.create(Parent);
    // Gleb.name = 'Gleb';
    // Gleb.country = 'Poland';

    // console.log(Gleb.name);
    // console.log(Gleb.surname);
    // console.log(Gleb.getInfo());

    // let Nina = {};
    // Nina.__proto__ = Gleb;
    // Nina.name = "Nina";

    // console.log(Nina.getInfo());

    // console.log(Nina);

    // Anton = Object.create(Parent);

    // Anton.name = 'Anton';
    // Anton.age = 20;

    // console.log(Anton);

    // let Animal = {
    // 	getInfo(){
    // 		return `My type is ${this.type}. Count of pows: ${this.countOfPaws}`;
    // 	},
    // 	countOfPaws: 4,
    // 	animals: {
    // 		fox: {
    // 			type: 'fox'
    // 		}
    // 	}
    // }

    // let cat = Object.create(Animal);
    // cat.type = 'cat';

    // console.log(cat);
    // console.log(cat.getInfo());

    // let dog = Object.create(Animal);
    // dog.type = 'dog';

    // console.log(dog);
    // console.log(dog.getInfo());

    // Animal.animals.fox.getInfo();

    const animals = [
        {
            name: 'dog',
            icon: '🐶'
        },
        {
            name: 'cat',
            icon: '🐱'
        },
        {
            name: 'hamster',
            icon: '🐹'
        },
        {
            name: 'rabbit',
            icon: '🐰'
        }
    ];
    console.log(animals);

    const Animal = {
        getInfo() {
            return `Name: ${this.name}. Icon: ${this.icon}.`;
        }
    }

    let modifiedAnimals = animals
        .map(
            function (animal) {
                let newAnimal = Object.create(Animal);
                // newAnimal.name = animal.name;
                // newAnimal.icon = animal.icon;

                for (let key in animal) {
                    newAnimal[key] = animal[key];
                }

                //console.log(newAnimal);
                return newAnimal;
            }
        )
        .map(
            function (animal) {
                return `<li>${animal.getInfo()}</li>`;
            }
        )
        .join('');

    document.write(`<ul>${modifiedAnimals}</ul>`);

    // Function-costructor

    // Class
}
// ! 16
let f16 = () => {
    // const CONTINENT = {
    // 	getInfo(){
    // 		return `<tr>
    // 			<td>${this.name}</td>
    // 			<td>${this.population}</td>
    // 		</tr>`;
    // 	}
    // }

    // const Africa = {
    // 	name: "Africa",
    // 	population: 1275920972
    // }

    // const Europe = {
    // 	name: "Europe",
    // 	population: 746419440
    // }

    // const AfricanСountries = [
    // 	{
    // 		name: "Nigeria",
    // 		population: 206139589
    // 	},
    // 	{
    // 		name: "Ethiopia",
    // 		population: 114963588
    // 	},
    // 	{
    // 		name: "Egypt",
    // 		population: 102334404
    // 	}
    // ];

    // const EuropeanСountries = [
    // 	{
    // 		name: "Monaco",
    // 		population: 39242
    // 	},
    // 	{
    // 		name: "Liechtenstein",
    // 		population: 38128
    // 	},
    // 	{

    // 		name: "San Marino",
    // 		population: 33931
    // 	}
    // ];

    // function makeProto(obj, proto){
    // 	let newObj = Object.create(proto);
    // 	for(let key in obj){
    // 		newObj[key] = obj[key];
    // 	}

    // 	return newObj;
    // }

    // function renderContinentInfo(countriesList, continentProto){
    // 	continentProto = makeProto(continentProto, CONTINENT);

    // 	let TRsСountries = countriesList
    // 		.map(country => makeProto(country, continentProto))
    // 		.map(country => country.getInfo())
    // 		.join(``);

    // 	return `<table>
    // 		<caption>${continentProto.name}</caption>
    // 		<thead>
    // 			<tr>
    // 				<th>Name</th>
    // 				<th>Population</th>
    // 			</tr>
    // 		</thead>
    // 		<tbody>
    // 			${TRsСountries}
    // 		</tbody>
    // 	</table>`;
    // }

    // let data = [
    // 	{
    // 		countriesList: AfricanСountries,
    // 		continent: Africa
    // 	},
    // 	{
    // 		countriesList: EuropeanСountries,
    // 		continent: Europe
    // 	}
    // ];

    // let continentsTable = data
    // 	.map(item => renderContinentInfo(item.countriesList, item.continent))
    // 	.join('');

    // document.write(continentsTable);

    // function-constructor

    // let Human = {
    // 	getInfo(){
    // 		return `Hello, my name is ${this.name} ${this.surname}. I'm ${this.age} years old.`;
    // 	}
    // }

    // let Vladimir = Object.create(Human);
    // Vladimir.name = "Vladimir";
    // Vladimir.surname = "Vladimirov";
    // Vladimir.age = 20;

    // console.log(Vladimir.getInfo());

    // let Nina = Object.create(Human);
    // Nina.name = "Nina";
    // Nina.surname = "Vladimirova";
    // Nina.age = 30;

    // console.log(Nina.getInfo());


    // function Human(name, surname, age, country="Ukraine"){
    // 	this.name = name;

    // 	if(!surname){
    // 		surname = prompt(`Enter surname`);
    // 	}

    // 	this.surname = surname;

    // 	this.fullName = `${name} ${surname}`;
    // 	this.age = age;
    // 	this.country = country;
    // }

    // Human.prototype.getInfo = function(){
    // 	return `Hello, my name is ${this.name} ${this.surname}. I'm ${this.age} years old.`;
    // }

    // Human.prototype.nationality = "ukrainian";

    // let Vladimir = new Human('Vladimir', "Vladimirov", 20);
    // console.log(Vladimir);

    // let NinaInfo = ['Nina', "Vladimirova", 30, "USA", "New York"];
    // let Nina = new Human(...NinaInfo);
    // console.log(Nina);

    // Animal

    // function Animal(type, name){
    // 	this.type = type;
    // 	this.name = name;
    // }

    // Animal.prototype.countOfPaws = 4;
    // Animal.prototype.getInfo = function(){
    // 	let info = [];
    // 	for(let key in this){
    // 		// if(this.hasOwnProperty(key)){
    // 		// 	info.push(`${key}: ${this[key]}`); // `type: cat``
    // 		// }

    // 		if(typeof this[key] !== 'function'){
    // 			info.push(`${key}: ${this[key]}`); // `type: cat``
    // 		}
    // 	}

    // 	return info.join(`\n`);
    // };

    // let Tom = new Animal("cat", "Tom");
    // let Jerry = new Animal("mouse", "Jerry");

    // console.log(Tom);
    // console.log(Jerry);

    // console.log(Tom.countOfPaws);

    // console.log(Tom.getInfo());
    // console.log(Jerry.getInfo());


    // let Grandparent = {
    // 	country: 'Ukraine'
    // }

    // let Parent = Object.create(Grandparent);
    // Parent.city = 'Kiev';

    // let Child = Object.create(Parent);
    // Child.name = 'Dmitry';

    // console.log(Child);
    // console.log(Child.country);

    // function Grandparent(){}
    // Grandparent.prototype.country = "Ukraine";

    // function Parent(){}
    // Parent.prototype = Object.create(Grandparent.prototype);
    // Parent.prototype.city = "Kiev";

    // function Child(name){
    // 	this.name = name;
    // }
    // Child.prototype = Object.create(Parent.prototype);
    // Child.prototype.surname = "Vladimirov";

    // let Dmitry = new Child("Dmitry");
    // console.log(Dmitry);

    // let Nina = new Child("Nina");
    // console.log(Nina);

    // console.log(Nina.country, Dmitry.country);

    function Animal(type, voice) {
        this.type = type;
        this.voice = voice;
    }

    Animal.prototype.getVoice = function () {
        return `I can say ${this.voice}.`
    }
    Animal.prototype.getName = function () {
        return `My name is ${this.type}.`
    }

    function Hishnik(type, voice) {
        this.type = type;
        this.voice = voice;
    }

    Hishnik.prototype = Object.create(Animal.prototype);
    Hishnik.prototype.getVoice = function () {
        return `I can say ${this.voice}!`
    }

    let Lion = new Hishnik('Lion', 'arrrr');
    console.log(Lion);
    console.log(Lion.getVoice());
    console.log(Lion.getName());

    let Pumba = new Animal('Pumba', 'auf');
    console.log(Pumba);
    console.log(Pumba.getVoice());
    console.log(Pumba.getName());


    // class

    // OOP
    // Средние показатели мужчин на длинные дистанции – 15-20 км/ч, у девушек – 12-15.

    // SOLID

}
// ! 17
let f17 = () => {
    // class

    // function Parent(name, age){
    // 	this.name = name;
    // 	this.age = age;
    // }

    // Parent.prototype.getInfo = function(){
    // 	return `Name: ${this.name}. Age: ${this.age}.`;
    // }

    // let Jack = new Parent('Jack', 30);
    // console.log(Jack);
    // console.log(Jack.getInfo());

    // function Child(name, age, number){
    // 	this.name = name;
    // 	this.age = age;
    // 	this.number = number;
    // }

    // Child.prototype = Object.create(Parent.prototype);

    // Child.prototype.getNumber = function(){
    // 	return `Child number: ${this.number}`;
    // }

    // let Anton = new Child("Anton", 7, 2);

    // console.log(Anton);
    // console.log(Anton.getNumber());
    // console.log(Anton.getInfo());

    // class

    // class Grandparent{
    // 	constructor(human){
    // 		this.name = human.name;
    // 		this.age = human.age;
    // 		this.surname = "Ivanenko";
    // 	}

    // 	sayHello(){
    // 		return `Hello, ${this.name}!`;
    // 	}
    // }

    // class Parent extends Grandparent{
    // 	constructor(human){
    // 		super(human);
    // 		this.country = human.country ? human.country : "Ukraine";
    // 	}

    // 	getInfo(){
    // 		return `Name: ${this.name}. Age: ${this.age}.`;
    // 	}

    // 	getName(){
    // 		return `Name: ${this.name}.`;
    // 	}

    // 	getAge(){
    // 		return `Age: ${this.age}.`;
    // 	}

    // 	getCity(){
    // 		return "Kiev";
    // 	}
    // }

    // let Jack = new Parent('Jack', 30);
    // console.log(Jack);
    // console.log(Jack.getInfo());

    // console.log(Jack.getCity());

    // class Child extends Parent{
    // 	constructor(human){
    // 		super(human);
    // 		this.number = human.number;
    // 	}

    // 	getNumber(){
    // 		return `Child number: ${this.number}`;
    // 	}
    // }

    // let Anton = new Child("Anton", 7, 2);
    // console.log(Anton);
    // console.log(Anton.getNumber());
    // console.log(Anton.getInfo());

    // let users = [
    // 	{
    // 		status: "parent",
    // 		name: "Parent 1",
    // 		age: 50
    // 	},
    // 	{
    // 		status: "parent",
    // 		name: "Parent 2",
    // 		age: 60
    // 	},
    // 	{
    // 		status: "child",
    // 		name: "Child 1",
    // 		age: 6,
    // 		number: 1
    // 	},
    // 	{
    // 		status: "child",
    // 		name: "Child 2",
    // 		age: 7,
    // 		number: 2
    // 	},
    // 	{
    // 		name: "Human",
    // 		age: 700
    // 	}
    // ];

    // const userStatus = {
    // 	parent: human => new Parent(human),
    // 	child: human => new Child(human)
    // }

    // users
    // 	.map(human => {
    // 		return userStatus[human.status] ? userStatus[human.status](human) : new Grandparent(human);
    // 	})
    // 	.forEach(human => console.log(human.sayHello()));

    // let colors = ['red', 'green', 'blue', ['orange', 'purple']];
    // let [red, green, blue, [orange, purple]] = colors;
    // console.log(blue, purple);

    // // sedan, coupe

    // Car
    // 	getInfo()

    // Audi => Car
    // 	getQ()
    // BMW => Car
    // 	getX()

    // AudiQ7
    // BMWX5

    class Car {
        constructor(name, type) {
            this.name = name;
            this.type = type;
        }

        getInfo() {
            return this.getOptions().join(`\n`);
        }

        getOptions() {
            let options = [this.getName(), this.getType()];
            return options;
        }

        getName() {
            return `Name: ${this.name}.`;
        }

        getType() {
            return `Type: ${this.type}.`;
        }
    }

    class Audi extends Car {
        constructor(name, type, Q) {
            super(name, type);
            this.Q = Q;
        }

        getQ() {
            return `Q: ${this.Q}.`;
        }

        getOptions() {
            let options = super.getOptions();
            options.push(this.getQ());

            return options;
        }
    }

    class BMW extends Car {
        constructor(name, type, X) {
            super(name, type);
            this.X = X;
        }

        getX() {
            return `X: ${this.X}.`;
        }

        getOptions() {
            let options = super.getOptions();
            options.push(this.getX());

            return options;
        }
    }

    const AudiQ7 = new Audi(`AudiQ7`, 'sedan', 7);
    const BMWX5 = new BMW('BMWX5', 'coupe', 5);

    console.log(AudiQ7.getInfo());
    console.log(BMWX5.getInfo());

    // OOP
    // Средние показатели мужчин на длинные дистанции – 15-20 км/ч, у девушек – 12-15.

    // SOLID

    // const ANIMALS = [
    // 	{
    // 		group: 'bird',
    // 		name: 'flamingo',
    // 		icon: '🦩'
    // 	},
    // 	{
    // 		group: 'bird',
    // 		name: 'parrot',
    // 		icon: '🦜'
    // 	},
    // 	{
    // 		group: 'mammal',
    // 		name: 'lion',
    // 		icon: '🦁'
    // 	},
    // 	{
    // 		group: 'mammal',
    // 		name: 'horse',
    // 		icon: '🐴'
    // 	},
    // 	{
    // 		group: 'fish',
    // 		name: 'tropical fish',
    // 		icon: '🐠'
    // 	},
    // 	{
    // 		group: 'fish',
    // 		name: 'blowfish',
    // 		icon: '🐡'
    // 	},
    // 	{
    // 		group: 'smth',
    // 		name: 'dog',
    // 		icon: '~'
    // 	}
    // ];

    // <li>
    // 	Name: lion. 
    // 	Icon: 🦁. 
    // 	Group: mammal.
    // </li>

    // Animal

    // Bird => Animal
    // Mammal => Animal
    // Fish => Animal
}
// ! 18
let f18 = () => {
    // Средние показатели мужчин на длинные дистанции – 15-20 км/ч, у девушек – 12-15.

    class Human {
        constructor(name, smoking = false) {
            this.name = name;
            this.smoking = smoking;
            this.speed = 15;
        }

        getSmokingKoef() {
            return 0.8;
        }

        getTime(distance = 1000) {
            let time = distance / this.speed;

            if (this.smoking) {
                time /= this.getSmokingKoef();
            }

            return Math.round(time);
        }
    }

    class Woman extends Human {
        constructor(name, smoking, hasChild = false) {
            super(name, smoking);
            this.speed = 13;
            this.hasChild = hasChild;
        }

        getChildKoef() {
            return 0.9;
        }

        getTime(distance) {
            let time = super.getTime(distance);

            if (this.hasChild) {
                time /= this.getChildKoef();
            }

            return Math.round(time);
        }
    }

    class Man extends Human {
        constructor(name, smoking) {
            super(name, smoking);
            this.speed = 17;
        }
    }

    let Anna = new Woman('Anna', true, true);
    let Nina = new Woman('Nina', false, true);

    let Ivan = new Man('Ivan');

    // console.log(Anna);
    // console.log(Ivan);

    // console.log(Anna.getTime());
    // console.log(Nina.getTime());

    // console.log(Ivan.getTime());

    // SOLID

    const ANIMALS = [
        {
            group: 'bird',
            name: 'flamingo',
            icon: '🦩'
        },
        {
            group: 'bird',
            name: 'parrot',
            icon: '🦜'
        },
        {
            group: 'mammal',
            name: 'lion',
            icon: '🦁'
        },
        {
            group: 'mammal',
            name: 'horse',
            icon: '🐴'
        },
        {
            group: 'fish',
            name: 'tropical fish',
            icon: '🐠'
        },
        {
            group: 'fish',
            name: 'blowfish',
            icon: '🐡'
        },
        {
            group: 'smth',
            name: 'dog',
            icon: '~'
        }
    ];

    // <li>
    // 	Name: lion. 
    // 	Icon: 🦁. 
    // 	Group: mammal.
    // </li>

    class Animal {
        constructor(animal) {
            for (let key in animal) {
                this[key] = animal[key];
            }
        }

        getInfo() {
            let li = [];
            for (let key in this) {
                li.push(`${key}: ${this[key]}`);
            }

            return `<li>${li.join(`<br>`)}</li>`;
        }
    }

    class Bird extends Animal {
        constructor(animal) {
            super(animal);
            this.voice = 'kurlyk';
        }

        getVoice() {
            return `kurlyk`;
        }
    }

    class Mammal extends Animal {
        constructor(animal) {
            super(animal);
        }
    }

    class Fish extends Animal {
        constructor(animal) {
            super(animal);
        }

        getVoice() {
            return `auuu`;
        }
    }

    const GROUPS = {
        bird: animal => new Bird(animal),
        mammal: animal => new Mammal(animal),
        fish: animal => new Fish(animal)
    };

    let renderAnimals = ANIMALS
        .map(animal => {
            // if(GROUPS[animal.group]){
            // 	return GROUPS[animal.group](animal);
            // } else{
            // 	return new Animal(animal);
            // }
            return GROUPS[animal.group] ? GROUPS[animal.group](animal) : new Animal(animal);
        })
        .map(animal => animal.getInfo())
        .join(``);

    //document.write(`<ul>${renderAnimals}</ul>`);

    // Animal

    // Bird => Animal
    // Mammal => Animal
    // Fish => Animal

    // get/set

    class Car {
        constructor(name) {
            this.name = name;
        }

        // getMaxSpeed(){
        // 	return this.maxSpeed ? this.maxSpeed : 300;
        // }

        // setMaxSpeed(value, year){
        // 	this.maxSpeed = year>=2000 ? value+10 : value;
        // }

        get maxSpeed() {
            return this.maxSpeedValue ? this.maxSpeedValue : 300;
        }

        set maxSpeed(obj) {
            this.maxSpeedValue = obj.year >= 2000 ? obj.speed + 10 : obj.speed;
        }

    }

    let AudiRS = new Car('AudiRS');
    let BMWX5 = new Car('BMWX5');

    console.log(AudiRS.maxSpeed);
    AudiRS.maxSpeed = { speed: 310, year: 2020 };
    console.log(AudiRS.maxSpeed);

    // AudiRS.setMaxSpeed(310, 2020);

    // console.log(AudiRS.getMaxSpeed());

    // AudiRS.setMaxSpeed(320);

    // console.log(AudiRS.getMaxSpeed());

    // defineProperty

    // Деструктурирующее присваивание

    // static


}
// ! 19
let f19 = () => {
    // static

    // class Weather{

    // 	getWind(){
    // 		return 3.14;
    // 	}

    // 	static getWind(){
    // 		return 3.14;
    // 	}
    // }

    // let today = new Weather();

    // console.log( today.getWind() );

    // console.log( Weather.getWind() );

    // console.log();

    // class Animal{

    // 	constructor(name){
    // 		this.name = name;
    // 	}

    // 	getHi(){
    // 		return `Hello, ${this.getName()}.`
    // 	}

    // 	getName(){
    // 		return this.name;
    // 	}

    // 	static getHi(animal){
    // 		return `Hello, animal ${animal.name}!`;
    // 	}

    // 	static animalData(){
    // 		return `animal data`;
    // 	}
    // }

    // class User{
    // 	static getHi(){
    // 		return `Hello, user!`;
    // 	}
    // }

    // let Cat = new Animal('Anfisa');

    // console.log( Cat.getHi() );

    // console.log(Animal.getHi(Cat));
    // console.log(User.getHi());


    // class GrandParent{
    // 	static getCountry(){
    // 		return `Ukraine`;
    // 	}
    // }

    // class Parent extends GrandParent{
    // 	static getCity(){
    // 		return "kiev";
    // 	}
    // }

    // console.log(Parent.getCountry());

    // class Activity{
    // 	static getBanner(){
    // 		return `black friday!`;
    // 	}
    // }

    // class Product{
    // 	static getBanner(){
    // 		return `black friday!`;
    // 	}
    // }

    // Product.getBanner();

    // defineProperty

    // const x = [100];

    // x[0]++;

    // console.log(x);

    // const admin = 1;

    // const PASS = {
    // 	admin: admin,
    // 	student: 2
    // }

    // PASS.admin = 10;
    // console.log(PASS);

    // const user = {
    // 	name: 'Anna'
    // }

    // user.name = 'Dima';

    // Object.defineProperty(user, 'name', {
    // 	writable: false,
    // 	configurable: false,
    // 	// value: 'Dima'
    // })

    // Object.defineProperty(user, 'age', {
    // 	value: 23
    // })

    // Object.defineProperty(user, 'getName', {
    // 	value: function(value){
    // 		return `Hello, ${value}`;
    // 	}
    // })

    // user.age = 100;
    // delete user.age;

    // delete user.name;

    // console.log(user);

    // console.log(user.getName('Vladimir'));


    // const user = {
    // 	name: 'Anna',
    // 	age: 23,
    // 	getName(){
    // 		return 'hello';
    // 	},
    // 	surname: 'Ivanov'
    // }

    // console.log(user);

    // Object.defineProperty(user, 'age', {
    // 	enumerable: false
    // })

    // Object.defineProperty(user, 'country', {
    // 	value: 'Ukraine',
    // 	// enumerable: true
    // })

    // Object.defineProperty(user, 'getName', {
    // 	enumerable: false
    // })


    // for(let key in user){
    // 	//console.log(user[key]);
    // 	Object.defineProperty(user, key, {
    // 		enumerable: false
    // 	});
    // }

    // let arr = [1,2,3];
    // arr.name = "anna";

    // for(let key in arr){
    // 	console.log(key);
    // }

    // class User{
    // 	constructor(user){
    // 		for(let key in user){
    // 			this[key] = user[key];
    // 		}

    // 		for(let key in this){
    // 			Object.defineProperty(this, key, {
    // 				writable: false,
    // 				configurable: false
    // 			});
    // 		}
    // 	}
    // }

    // let Anna = new User(user);
    // console.log(Anna);


    // let user = {};

    // Object.defineProperty(user, 'name', {
    // 	get: function(){
    // 		return this.userName ? this.userName : 'Anna';
    // 	},
    // 	set: function(value){
    // 		this.userName = value;
    // 	}
    // })

    // console.log(user);
    // console.log(user.name);
    // user.name = 'Igor';
    // console.log(user.name);


    // let user = {};

    // let userName = "Anna";
    // Object.defineProperty(user, 'name', {
    // 	get: function(){
    // 		return userName;
    // 	},
    // 	set: function(value){
    // 		userName = value;
    // 	}
    // })

    // console.log(user);

    // console.log(user.name);
    // user.name = 'Igor';
    // console.log(user.name);

    // let users = ['Anna','Ivan'];

    // let usersNew = users
    // 	.map(user => {
    // 		let newUser = {};

    // 		Object.defineProperty(newUser, 'name', {
    // 			get: function(){
    // 				return this.userName ? this.userName : user;
    // 			},
    // 			set: function(value){
    // 				this.userName = value;
    // 			}
    // 		})

    // 		return newUser;
    // 	});

    // console.log(usersNew);

    // let animal = {};
    // Object.defineProperty(animal, 'name', {
    // 	get: function(){
    // 		return userName;
    // 	},
    // 	set: function(value){
    // 		userName = value;
    // 	}
    // })
    // animal.name = 'Simba';

    // console.log(user.name);


    // Деструктурирующее присваивание


    // let colors = ['red', 'green', 'blue', ['orange', 'purple'], {name: 'Anton'}];

    // // let red = colors[0];
    // // let green = colors[1];
    // // let blue = colors[2];

    // // let purple = colors[3][1];

    // let [red,,,[orange, purple], {name:antonName} ] = colors;

    // console.log(red);
    // // console.log(green);
    // // console.log(blue);

    // console.log(purple);

    // console.log(antonName);

    let colors = ['red', undefined, 'green', 'orange', 'pink', 'yellow'];

    let [red, blue = 'blue', green, ...otherColors] = colors;

    console.log(red);
    console.log(blue);
    console.log(green);

    console.log(otherColors);

    function showMenu(title = "Untitled", width = 200, height = 100, items = []) {
        console.log(title);
        console.log(width);
        console.log(height);
        console.log(items);

        items.map(function (item) { })
    }

    showMenu(['Buu', 100, 200]);

    // call, apply, bind

    // DOM
}
// ! 20
let f20 = () => {
    // call static method from object

    // class User{
    // 	constructor(name){
    // 		this.name = name;
    // 	}

    // 	static getInfo(){
    // 		return `User info.`
    // 	}
    // }

    // let Gleb = new User('Gleb');
    // console.log(Gleb);

    // console.log(Gleb.constructor.getInfo());
    // console.log(User.getInfo());

    // extends

    // class Grandparent{
    // 	get country(){
    // 		return 'Ukraine';
    // 	}

    // 	static get city(){
    // 		return `Kiev`;
    // 	}
    // }

    // class Father extends Grandparent{
    // 	constructor(){
    // 		super();
    // 	}

    // 	get country(){
    // 		let grandparentCountry = super.country;
    // 		return `${grandparentCountry}, Poland`;
    // 	}

    // 	get city(){
    // 		let grandparentCity = super.constructor.city;
    // 		return `${grandparentCity}, Odessa`;
    // 	}
    // }

    // let Alexandr = new Father();
    // console.log(Alexandr.country);

    // console.log(Alexandr.city);

    // call/apply/bind

    // function info(){
    // 	console.log(this);
    // 	return `Age: ${this.age}.`;
    // }

    // let user = {
    // 	age: 30,
    // 	getAge(){
    // 		return `Age: ${this.age}.`
    // 	}
    // }

    // let animal = {
    // 	age: 7
    // }

    // console.log( info.call(user) );
    // console.log( user.getAge() );

    // console.log( user.getAge.call(animal) );

    // class User{
    // 	constructor(name){
    // 		this.name = name;
    // 	}

    // 	static getInfo(){
    // 		return `${this.name ? this.name : `User`}, hello!`
    // 	}
    // }

    // let Gleb = new User('Gleb');

    // console.log(Gleb.constructor.getInfo.call(Gleb));
    // console.log(User.getInfo.call(Gleb));

    // console.log(User.getInfo());

    // function info(country=`Poland`, city=`Krakov`){
    // 	return `
    // 		Hello, ${this.name}.
    // 		Country: ${country}.
    // 		City: ${city}.
    // 	`;
    // }

    // let user = {
    // 	name: 'Anton'
    // }

    // let cat = {
    // 	name: 'Tom'
    // }

    // let SMTH = 'smth'

    // const data = [`Ukraine`,`Kiev`];

    // console.log( info.call(user) );
    // console.log( info.call(user,...data) );

    // console.log( info.apply(user,data) );
    // console.log( info.apply(user) );

    // const infoUser = info.bind(user,`Ukraine`,`Kiev`);
    // const infoCat = info.bind(cat,SMTH);

    // console.log( infoUser() );

    // console.log( infoCat() );
    // SMTH = 'else';
    // console.log( infoCat() );


    // Деструктурирующее присваивание

    // let colors = ['red', ,['black','white', ['dark','light']],'blue','orange','yellow'];
    // //console.log(colors);
    // //let [red, purple=`purple`, [black,,[,light]], blue, ...others] = colors;

    // function renderColors([red, purple=`purple`, [black,,[,light]=[]]=[], blue, ...others]=[]){
    // 	console.log(red);
    // 	console.log(purple);
    // 	console.log(blue);
    // 	console.log(others);

    // 	console.log(black);
    // 	console.log(light);
    // }

    // renderColors(colors);
    // renderColors();

    // let students = ['Anna','Gleb','Nina','Ivan','Petr','Katya'];

    // function getStudents([greates, greater, great, ...others]=[]){
    // 	console.log(`First: ${greates}`);
    // 	console.log(`Second: ${greater}`);
    // 	console.log(`Third: ${great}`);

    // 	console.log(others);
    // }

    // function getStudents(students){
    // 	let greates = students[0];
    // 	let greater = students[1];
    // 	let great = students[2];

    // 	let others = students.slice(3);

    // 	console.log(`First: ${greates}`);
    // 	console.log(`Second: ${greater}`);
    // 	console.log(`Third: ${great}`);

    // 	console.log(others);
    // }

    // getStudents(students)

    // let user = {
    // 	name: 'Ivan',
    // 	age: 30,
    // 	animals: [`cat`,`dog`],
    // 	homeland: {
    // 		country: 'Ukraine',
    // 		city: 'Kiev'
    // 	},
    // 	children: [
    // 		{
    // 			// name: `Child 1`,
    // 			age: 7,
    // 			sport: 'tennis'
    // 		},
    // 		{
    // 			name: `Child 2`,
    // 			age: 10
    // 		}
    // 	]
    // };

    // //let {children:[{age:childFirstAge, sport:childFirstSport='dance', name:childFirstName="Anton"}]} = user;

    // function userInfo({children:[{age:childFirstAge, sport:childFirstSport='dance', name:childFirstName="Anton"}]=[]} = {}){
    // 	console.log(childFirstAge, childFirstSport, childFirstName);
    // }

    // userInfo(user);

    // let colors = ['red',10];
    // let [red, [white, black]] = colors;

    // console.log(red);
    // console.log(white);
    // console.log(black);

    // function summ(x,y){
    // 	return x+y;
    // }

    // const summ = (x,y) => x+y;

    // class User{
    // 	_country = 'Ukraine';
    // 	#city = 'Kiev';

    // 	constructor(name){
    // 		this.name = name;
    // 	}

    // 	get country(){
    // 		return `My country: ${this._country}`;
    // 	}

    // 	set country(value){
    // 		this._country = value;
    // 	}

    // 	get city(){
    // 		return `My city: ${this.#city}`;
    // 	}

    // 	set city(value){
    // 		this.#city = value;
    // 	}

    // 	superFunc(){
    // 		return `Data from super function ${this.#city}.`
    // 	}
    // }

    // let Jack = new User(`Jack`);
    // console.log(Jack);

    // console.log(Jack._country);
    // console.log(Jack.country);

    // console.log(`****`);

    // Jack.country = 'Poland';
    // console.log(Jack.country);

    // console.log( Jack.city );
    // Jack.city = 'Odessa';
    // console.log( Jack.city );

    // console.log(Jack.superFunc());

    // public _var and private #var

    // Примеси

    // DOM

}
// ! 21
let f21 = () => {
    // DOM

    // const h2 = document.querySelector(`section article:nth-child(70) > h2:nth-child(2)`);
    // const headers = document.querySelectorAll(`h1`);
    // headers.forEach(h1 => console.log(h1));

    // const h1 = document.querySelector(`.example`);
    // console.dir(h1);

    // h1.dataset.sale = true;
    // delete h1.dataset.id;

    // h1.innerText = 'New <i>data</i>';
    // h1.innerHTML += ' New <i>data</i>';
    // h1.align = "center";

    // console.log(h1.style.color);
    // h1.style.background = h1.style.color === 'green' ? 'yellow' : 'red';

    // h1.style.color = 'blue';
    // h1.style.height = '30px';
    // h1.style.width = '30px';
    // h1.style.border = '2px solid green';
    // h1.style.borderRadius = '50%';


    // setTimeout(()=>{
    // 	h1.style.color = '';
    // 	h1.style.height = '';
    // 	h1.style.width = '';
    // 	h1.style.border = '';
    // 	h1.style.borderRadius = '';
    // },1000);

    // h1.className += ` active`;
    // setTimeout(()=>{
    // 	h1.className = h1.className.replace(` active`,``);
    // },1000)

    // console.log(h1.classList.contains(`active`));
    // h1.classList.add(`active`);

    // setTimeout(()=>{
    // 	h1.classList.remove(`active`);
    // },1000)

    // setInterval(()=>{
    // 	// if(h1.classList.contains('active')){
    // 	// 	h1.classList.remove('active');
    // 	// } else{
    // 	// 	h1.classList.add('active');
    // 	// }

    // 	h1.classList.toggle('active');
    // },1000);

    // style

    // className
    // classList

    // setTimeout(()=>h1.id = 'newId', 1000);

    // setAttribute/removeAttribute

    // console.log( h1.getAttribute(`id`));

    // console.log(h1.getAttribute('kotik'));
    // h1.setAttribute('sobachka','Timka');
    // h1.removeAttribute('id');

    // data-attributes

    // .remove()

    // setTimeout(()=>h1.remove(),1000);
    // setTimeout(()=>document.querySelector(`body`).append(h1),2000);
    // setTimeout(()=>document.querySelector(`body`).prepend(h1),3000);

    // const wrapper = document.querySelector(`.wrapper`);
    // wrapper.innerHTML = `<h2>Header 2</h2>` + wrapper.innerHTML;

    // const h2 = document.createElement(`h2`);
    // h2.innerHTML = 'Header 2';
    // h2.className = 'active';
    // console.dir(h2);

    // wrapper.append(h2);
    //wrapper.innerHTML += h2;

    // document.createElement()
    // .append()

    // console.log(h1.textContent);
    // console.log(h1.innerHTML);

    // h1.innerHTML += ` <i>hello</i>`;

    // const liSecond = document.querySelector(`li:nth-child(2)`);
    // console.dir(liSecond);

    // liSecond.parentNode.style.border = '1px solid pink';

    // liSecond.nextElementSibling.style.color = 'orange';
    // liSecond.previousElementSibling.style.color = 'red';

    // const liSpecial = document.querySelector(`li.special`);
    // const liNotSpecial = liSpecial.parentNode.querySelectorAll(`li:not(.special)`);

    // liNotSpecial.forEach(li => li.style.color = 'orange');

    // var color = window.getComputedStyle(
    // 	document.querySelector(`li.special`), ':before'
    // ).getPropertyValue('content');

    // console.log(color);

    const h1 = document.querySelector(`h1`);

    // const myHRBefore = document.createElement(`hr`);
    // const myHRAfter = document.createElement(`hr`);

    // h1.before(myHRBefore);
    // h1.after(myHRAfter);

    console.log(h1.innerHTML);
    h1.outerHTML = `<h2>${h1.innerHTML}</h2>`;

}
// ! 22
let f22 = () => {
    // mouse events
    // onmouseenter/onmouseleave
    // 	onmouseover/onmouseout
    // 	onmousemove

    // const block = document.querySelector(`.block`);

    // const mouseEnterFunc = event => {
    // 	console.log(event.type);
    // 	console.dir(event.target);

    // 	event.target.classList.toggle(`active`);
    // };

    // function handler(e){
    // 	console.log(e);

    // 	console.log(e.type);
    // 	// console.dir(e.target);

    // 	// e.target.classList.toggle(`active`);
    // };

    // block.onmouseenter = handler;
    // block.onmouseover = handler;

    // block.onmouseleave = handler;
    // block.onmouseout = handler;

    // block.onmousemove = handler;

    // block.onmousedown = handler;
    // block.onmouseup = handler;

    // mouse events
    // 	onmousedown
    // 	onmouseup

    // Drag & drop

    // const block = document.querySelector(`.block`);

    // let blockActivated = false;

    // let x,y;

    // block.onmousedown = e => {
    // 	console.dir(e);

    // 	x = e.clientX;
    // 	y = e.clientY;

    // 	console.log(x,y, e.type);

    // 	blockActivated = true;
    // }

    // block.onmousemove = e => {
    // 	if(blockActivated){
    // 		console.dir(e);

    // 		x_ = e.clientX;
    // 		y_ = e.clientY;

    // 		console.log(x_,y_, e.type);

    // 		diff_x = x_ - x;
    // 		diff_y = y_ - y;

    // 		console.log(`Left: ${diff_x}. Top: ${diff_y}`);

    // 		block.style.left = block.style.left === '' ? `${diff_x}px` : `${parseInt(block.style.left) + diff_x}px`;
    // 		block.style.top = block.style.top === '' ? `${diff_y}px` : `${parseInt(block.style.top) + diff_y}px`;

    // 		x = x_;
    // 		y = y_;
    // 	}
    // }

    // document.onmouseup = e => {
    // 	if(blockActivated){
    // 		console.dir(e);

    // 		x_ = e.clientX;
    // 		y_ = e.clientY;

    // 		console.log(x_,y_, e.type);

    // 		diff_x = x_ - x;
    // 		diff_y = y_ - y;

    // 		console.log(`Left: ${diff_x}. Top: ${diff_y}`);

    // 		block.style.left = block.style.left === '' ? `${diff_x}px` : `${parseInt(block.style.left) + diff_x}px`;
    // 		block.style.top = block.style.top === '' ? `${diff_y}px` : `${parseInt(block.style.top) + diff_y}px`;
    // 		blockActivated = false;
    // 	}
    // }

    // const block = document.querySelector(`.block`);

    // const handler = e => {
    // 	console.log(e.type);
    // }

    // block.onmousedown = handler;
    // block.onmouseup = handler;
    // block.onclick = handler;

    // block.ondblclick = handler;
    // block.oncontextmenu = handler;

    const link = document.querySelector(`#link`);

    // link.onclick = e => {
    // 	e.preventDefault();

    // 	console.log('click');

    // 	// setTimeout(()=> document.location.href = link.href ,1000);
    // 	setTimeout(()=> window.open(link.href, '_blank') ,1000);
    // }

    // let clicked = false;

    // link.onclick = e => {
    // 	e.preventDefault();

    // 	if(!clicked){
    // 		window.open('https://www.guestreservations.com/hilton-kyiv/booking', '_blank');
    // 		clicked = true;
    // 	} else{
    // 		document.location.href = link.href;
    // 	}

    // }

    // console.log(link.dataset);

    // link.onclick = e => {
    // 	e.preventDefault();
    // 	document.location.href = link.dataset.href;
    // }


    // click events
    // 	onclick
    // 	ondblclick
    // 	oncontextmenu

    // preventDefault()

    // const handler = e => {
    // 	console.log(e.type);

    // 	console.log(e);
    // }

    // document.onkeypress = handler;
    // document.onkeydown = handler;
    // document.onkeyup = handler;

    // keyboard events
    // 	onkeypress
    // 	onkeydown
    // 	onkeyup

}
// ! 23
let f23 = () => {
    // const block = document.querySelector(`.block`);

    // const STEP = 50;

    // const maxOffsetLeft = (windowWidth=window.innerWidth) => windowWidth - block.offsetWidth;
    // let maxOffsetTop = window.innerHeight - block.offsetHeight;

    // const EVENTS = {
    //   38: () => console.log('in 38'),
    //   39: () => {
    //     let nextOffsetLeft = block.offsetLeft + STEP;

    //     if(nextOffsetLeft>maxOffsetLeft()){
    //       block.style.left = `${parseInt(block.style.left) - STEP}px`;

    //       block.classList.add(`bems`);
    //       setTimeout(()=>block.classList.remove(`bems`), 1000);

    //     } else{
    //       block.style.left = !block.style.left ? `${STEP}px` : `${parseInt(block.style.left) + STEP}px`;
    //     }
    //   },
    //   40: () => console.log('in 40')
    // }

    // document.onkeydown = event => {
    //   EVENTS[event.keyCode] && EVENTS[event.keyCode]();
    // }

    // window.onresize = () => {
    //   maxOffsetLeft(window.innerWidth);
    //   console.log(window.innerWidth);
    // }

    // const MOBILE = 375;

    // block.onclick = () => {
    //   if(window.innerWidth <= MOBILE){
    //     console.log('mobile func');
    //   } else{
    //     console.log('desktop func');
    //   }
    // }

    // NEW

    // const block = document.querySelector(`.block`);

    // const firstFunc = () => console.log(`firstFunc`);
    // const secondFunc = () => console.log(`secondFunc`);

    // block.addEventListener('click', event=>console.log(event.type));
    // block.addEventListener('click', firstFunc);
    // block.addEventListener('click', secondFunc);

    // const link = document.querySelector(`#link`);

    // const pariMatch = e => {
    //   e.preventDefault();
    //   console.log(`pariMatch`);

    //   link.removeEventListener(`click`, pariMatch);

    //   link.addEventListener(`click`, e => {
    //     e.preventDefault();
    //     document.location.href = link.dataset.href;
    //   });
    // }

    // link.addEventListener(`click`, pariMatch)
    // link.addEventListener(`mouseenter`, ()=>{})
    // link.addEventListener(`mouseenter`, ()=>{})

    // const first = document.querySelector(`.first`);
    // const second = document.querySelector(`.second`);
    // const third = document.querySelector(`.third`);

    // first.addEventListener(`click`, ()=>{
    //   console.log('first function');
    // }, true)

    // second.addEventListener(`click`, event=>{
    //   console.log('second function');
    //   event.stopPropagation();
    // })

    // third.addEventListener(`click`, event=>{
    //   console.log('third function');
    // })

    // let x = 200;

    // f1(){
    //   let x = 100;
    //   f2();
    // }

    // function f2(){
    //   console.log(x);
    // }

    // const showBlock = document.querySelector(`#showBlock`);
    // const block = document.querySelector(`.block`);

    // block.addEventListener('click', e=>e.stopPropagation());

    // showBlock.addEventListener(`click`,e=>{
    //   block.classList.toggle('show');

    //   console.log('in btn func');

    //   e.stopPropagation();
    // })

    // document.addEventListener('click', ()=>{
    //   if(block.classList.contains('show')){
    //     block.classList.remove('show');
    //   }

    //   console.log('in document func');
    // })

    // INPUT

    const input = document.querySelector(`input`);
    const text = document.querySelector(`#text`);

    // input.addEventListener('keypress',e=>{
    //   console.log(e);
    //   console.log(e.key);
    //   console.log(e.target.value);
    // })


    // input.addEventListener('input',e=>{
    //   console.log(e.data);
    //   console.log(e.target.value);

    //   text.innerHTML = e.target.value;
    // })

    input.addEventListener('change', e => {
        console.log(e);
    })

}
// ! 24
let f24 = () => {
    // const block = document.querySelector(`.block`);

    // window.addEventListener(`resize`,()=>{
    // 	window.innerWidth<=768 ? block.classList.add(`active`) : block.classList.remove(`active`)
    // })

    // textarea

    // const textarea = document.querySelector(`textarea`);
    // console.log(textarea.innerHTML);
    // console.log(textarea.value);

    // console.dir(textarea);
    // textarea.value = 'JS value';

    // radio, checkbox

    // let size = document.querySelectorAll(`input[name="size"]`);
    // console.log(size);

    // size.forEach(input => {
    // 	input.addEventListener(`change`, ()=>{
    // 		console.log(input.value);
    // 	})
    // });

    //setTimeout(()=>alert(document.querySelector(`input[name="size"]:checked`).value),3000);

    // const userSizes = [];

    // const sizes = document.querySelectorAll(`input[name="size"]`);

    // sizes.forEach(input => {
    // 	if(input.checked)
    // 		userSizes.push(input.value);

    // 	input.addEventListener(`change`, ()=>{
    // 		if(input.checked){
    // 			userSizes.push(input.value)
    // 		} else{
    // 			let sizeIndex = userSizes.indexOf(input.value);
    // 			userSizes.splice(sizeIndex,1);
    // 		}

    // 		console.log(userSizes);
    // 	})
    // });

    // console.log(userSizes);

    // select

    // const selectedOptions = [];

    // const options = [...document.querySelector(`select`).children];
    // console.log(options);

    // options.forEach(option => {
    // 	option.addEventListener(`click`, ()=>{
    // 		if(option.selected){
    // 			selectedOptions.push(option.value);
    // 		} else{
    // 			let indexOption = selectedOptions.indexOf(option.value);
    // 			selectedOptions.splice(indexOption,1);
    // 		}

    // 		console.log(selectedOptions);
    // 	})

    // 	if(option.selected)
    // 		selectedOptions.push(option.value);
    // })

    // console.log(selectedOptions);

    // const foo = event => console.log(Math.round(Math.random()*10), event.target.value);
    // const select = document.querySelector(`select`);

    // // const doFunc = event => {
    // // 	foo(Math.round(Math.random()*10), select.value);
    // // }

    // select.addEventListener(`change`, foo);
    // setTimeout(()=>select.removeEventListener(`change`, foo),2000);

    // const blockBG = document.querySelector(`#blockBG`);
    // const block = document.querySelector(`.block`);

    // blockBG.addEventListener(`input`, ()=>{
    // 	block.style.background = blockBG.value;
    // });

    // const file = document.querySelector(`#file`);

    // file.addEventListener(`change`, ()=>{
    // 	console.log(file.value);
    // 	console.dir(file);
    // })

    // const form = document.querySelector(`form`);

    // form.addEventListener(`submit`,e=>{
    // 	e.preventDefault();

    // 	alert('Hello');

    // 	let name = document.querySelector(`#userName`).value;
    // 	let message = document.querySelector(`#userMessage`).value;

    // 	console.log(name);
    // 	console.log(message);

    // 	form.reset();
    // });

    // const login = document.querySelector(`#login`);
    // const register = document.querySelector(`#register`);

    // login.addEventListener(`submit`, e=>{
    // 	e.preventDefault();

    // 	let userEmail = e.target.querySelector(`input[name="userEmail"]`).value;
    // })

    // register.addEventListener(`submit`, e=>{
    // 	e.preventDefault();

    // 	let userEmail = e.target.querySelector(`input[name="userEmail"]`).value;
    // })

    // localStorage, sessionStorage

    // const login = document.querySelector(`#login`);

    // const users = [];

    // login.addEventListener(`submit`, e=>{
    // 	e.preventDefault();

    // 	let email = e.target.querySelector(`input[name="userEmail"]`).value;
    // 	//console.log(email);

    // 	users.push(email);
    // 	localStorage.setItem('email',users);
    // })

    // localStorage.setItem(`name`,'Ivan');
    // setTimeout(()=>alert(localStorage.getItem(`name`)), 1000);
    // setTimeout(()=>localStorage.removeItem(`name`), 2000);

    // const user = {
    // 	name: 'Anton',
    // 	age: 13
    // }

    // let userJSON = JSON.stringify(user);
    // console.log(userJSON);

    // localStorage.setItem('user', userJSON);

    // console.log( JSON.parse(localStorage.getItem('user')) );

    // const age = 13;
    // localStorage.setItem(`age`, age);
    // console.log( JSON.parse( localStorage.getItem(`age`) ) );

    // const isFree = 'true';
    // localStorage.setItem(`isFree`, JSON.stringify(isFree));
    // console.log( localStorage.getItem(`isFree`) );

    // const animals = ['cat','dog'];
    // localStorage.setItem('animals', JSON.stringify(animals));
    // console.log( JSON.parse( localStorage.getItem(`animals`) ) );

    // document.addEventListener('mouseout', e => {
    // 	if (!e.toElement && !e.relatedTarget) {
    // 		console.log(e.type);
    // 	}
    // });


    // calendar
}
// ! 25
let f25 = () => {
    const DAYS = ['Monday', "Tuesday", "Wednesday", "Thursday", "Friday"];
    let [Monday, Tuesday, Wednesday, Thursday, Friday] = DAYS;

    const ROOMS = {
        Red: {
            hours: {
                start: 10,
                end: 19
            },
            days: [Monday, Tuesday, Wednesday, Friday]
        },
        Green: {
            hours: {
                start: 11,
                end: 17
            },
            days: [Tuesday, Thursday, Friday]
        }
    }

    const Participants = ['Igor', 'Nina', 'Vladimir', 'Anna'];

    const meetForm = document.querySelector(`#meetForm`);
    const meetRoom = document.querySelector(`select[data-id="meetRoom"]`);
    const meetHours = document.querySelector(`select[data-id="meetHours"]`);
    const meetDays = document.querySelector(`select[data-id="meetDays"]`);

    const getRoomHours = roomName => {
        let hours = [],
            start = ROOMS[roomName].hours.start,
            end = ROOMS[roomName].hours.end;

        for (; start <= end; start++) {
            hours.push(start);
        }

        return hours;
    }

    const getRoomDays = roomName => ROOMS[roomName].days;

    const generateOptions = (el, func, room, itemView = "") => {
        el.innerHTML = func(room).map(item => `<option value="${item}">${item}${itemView}</option>`);
    }

    for (let key in ROOMS) {
        meetRoom.innerHTML += `<option value="${key}">${key}</option>`;
    }

    generateOptions(meetHours, getRoomHours, meetRoom.value, ":00");
    generateOptions(meetDays, getRoomDays, meetRoom.value);

    meetRoom.addEventListener(`change`, () => {
        generateOptions(meetHours, getRoomHours, meetRoom.value, ":00");
        generateOptions(meetDays, getRoomDays, meetRoom.value);
    })


    meetForm.addEventListener(`submit`, e => {
        e.preventDefault();

        let meetName = e.target.querySelector(`input[data-id="meetName"]`).value,
            meetParticipants = [...e.target.querySelector(`select[data-id="meetParticipants"]`).selectedOptions],
            room = meetRoom.value,
            hours = meetHours.value,
            days = meetDays.value;

        meetParticipants = meetParticipants.map(option => option.value);

        let meet = {
            name: meetName,
            room: room,
            participants: meetParticipants,
            hours: hours,
            days: days
        }

        let userNotExist = true;

        let storageParticipants = localStorage.getItem(`participants`) ? JSON.parse(localStorage.getItem(`participants`)) : {};

        meetParticipants.forEach(user => {
            if (storageParticipants[user]) {
                let userCalendar = storageParticipants[user];
                let userInMeet = userCalendar.find(meet => meet.day === days && meet.hour == hours && meet.room == room);

                if (userInMeet) {
                    alert(`${user} already in meet at ${room} ${hours}:00 ${days}.`);
                    userNotExist = false;
                } else {
                    storageParticipants[user].push({ hour: hours, day: days, room: room });
                }

            } else {
                storageParticipants[user] = [{ hour: hours, day: days, room: room }]
            }
        })

        if (userNotExist) {
            localStorage.setItem(`participants`, JSON.stringify(storageParticipants));

            let storageRooms = localStorage.getItem(`rooms`) ? JSON.parse(localStorage.getItem(`rooms`)) : {};
            let storageRoom;

            if (storageRooms[room]) {
                if (storageRooms[room].find(storageMeet => storageMeet.hours === hours && storageMeet.days === days)) {
                    alert(`Meet at ${hours}:00 in ${days} already exist!`);
                } else {
                    storageRoom = storageRooms[room];
                    storageRoom.push(meet);
                }
            } else {
                storageRooms[room] = [meet];
            }

            localStorage.setItem(`rooms`, JSON.stringify(storageRooms));
        }
    })

    // TABLES
    const meetTables = document.querySelector(`#meetTables`);

    const renderTable = () => {
        let storage = localStorage.getItem(`rooms`) ? JSON.parse(localStorage.getItem(`rooms`)) : {};

        for (let room in storage) {
            let table = document.createElement(`table`);
            table.innerHTML = `<caption>${room} meeting room</caption>
            <thead>
                <tr>
                    <th>Hours</th>
                    ${getRoomDays(room).map(day => `<th>${day}</th>`).join(``)}
                </tr>
            </thead>
            <tbody>
                ${getRoomHours(room).map(hour => `<tr>
                        <td>${hour}:00</td>
                        ${getRoomDays(room).map(day => `<td data-day="${day}" data-hour="${hour}"></td>`).join(``)}
                    </tr>`).join(``)}
            </tbody>`;

            meetTables.append(table);
        }
    };

    renderTable();

}
// ! 26
let f26 = () => {
    console.log('start');

    let xhr = new XMLHttpRequest();
    xhr.open("GET", "user.json");
    xhr.send();

    xhr.addEventListener('readystatechange', () => {
        if (xhr.readyState === 4 && xhr.status === 200) {
            console.log(xhr);
            console.log(JSON.parse(xhr.response));
        }
    })

    console.log('end');

    console.log(2);

    console.log(3);
}
// ! 27
let f27 = () => {
    // get file users.json
    // get file for each user from users.json and push to users ages to USER_AGES array;

    // console.log('before');

    // const USER_AGES = [];

    // const getUsers = arrUsers => arrUsers.forEach(user => {

    // 	console.log(`start getting file ${user}.json`);

    // 	let xhr = new XMLHttpRequest();
    // 	xhr.open('GET', `files/${user}.json`, true);
    // 	xhr.send();

    // 	xhr.addEventListener('readystatechange', ()=>{
    // 		// console.log(xhr.readyState);
    // 		if(xhr.readyState === 4 && xhr.status >= 200 && xhr.status<400){
    // 			let user = JSON.parse(xhr.response);
    // 			console.log(user);

    // 			USER_AGES.push(user.age);
    // 		}
    // 	})
    // });

    // setTimeout(()=>{
    // 	console.log(USER_AGES)
    // 	USER_AGES.forEach(age => console.log(age));
    // },2000);

    // let xhr = new XMLHttpRequest();
    // xhr.open('GET', 'files/users.json', true);
    // xhr.send();

    // xhr.addEventListener('readystatechange', ()=>{
    // 	// console.log(xhr.readyState);
    // 	if(xhr.readyState === 4 && xhr.status >= 200 && xhr.status<400){
    // 		let users = JSON.parse(xhr.response);
    // 		console.log(users);
    // 		getUsers(users);
    // 	}
    // })

    // console.log('after');

    // Event loop

    // function main() {
    // 	console.log('A')

    // 	setTimeout(
    // 		function exec() {
    // 	  		console.log('B')
    // 		},
    // 		0
    // 	)

    // 	// for(let i=0; i<=100; i++){
    // 	// 	console.log(i);
    // 	// }

    // 	console.log('C');
    // }

    // main();


    // A
    // B
    // C

    // Promise 💚💔

    // let cleanedRoom = true;

    // const thirdResolve = () => console.log('💚 third resolve');

    // const secondResolve = () => {
    // 	console.log('💚 second resolve');
    // 	thirdResolve();
    // }

    // const resolve = () => {
    // 	console.log('💚 Yes, go play.');
    // 	secondResolve();
    // };
    // const reject = () => console.log('💔 No, do the laundry.');

    // setTimeout(()=>{
    // 	cleanedRoom ? resolve() : reject();
    // },2000);

    // let cleanedRoom = true;
    // let markMath = 4;

    // let myPromise = new Promise(
    // 	function(resolve, reject){

    // 		setTimeout(()=>{
    // 			cleanedRoom ? resolve(markMath) : reject(markMath);
    // 		},100);

    // 	}
    // );

    // myPromise
    // 	.then(
    // 		function(mark){ 
    // 			console.log('💚 Yes, go play.');
    // 			return mark >= 7 ? Promise.resolve(mark) : Promise.reject(mark);
    // 		},
    // 		function(mark){ 
    // 			console.log('💔 No, do the laundry.');
    // 			return Promise.reject();
    // 		}
    // 	)
    // 	.then(
    // 		function(mark){ 
    // 			console.log('💚 Second resolve.') 
    // 			return mark >= 11 ? Promise.resolve() : Promise.reject();
    // 		},
    // 		function(mark){ 
    // 			console.log('💔 Second reject.') 
    // 			return mark >= 5 ? Promise.resolve() : Promise.reject();
    // 		}
    // 	)
    // 	.then(
    // 		function(){ console.log('💚 Third resolve.') },
    // 		function(){ console.log('💔 Third reject.') }
    // 	)


    // next

    let cleanedRoom = true;

    let myPromise = new Promise(
        (resolve, reject) => {
            setTimeout(() => {
                cleanedRoom ? resolve(100) : reject(100);
            }, 100);
        }
    )

    myPromise
        .finally(
            () => console.log('1 💚💚💚 in finally')
        )
        .then(
            x => {
                console.log('💚 in 1 resolve', x);
                //return Promise.reject(--x);
                return --x;
            }
        )
        .finally(
            () => console.log('2 💚💚💚 in finally')
        )
        .then(
            x => {
                console.log('💚 in 2 resolve', x);
                return --x;
            }
        )
        .then(
            x => console.log('💚 in 3 resolve', x)
        )
        .finally(
            () => console.log('3 💚💚💚 in finally')
        )
        .catch(
            x => console.log('💔 in catch', x)
        )
        .finally(
            () => console.log('4 💚💚💚 in finally')
        )

    // then, finally, catch

    // Promise.all(), Promise.allSettled()
}
// ! 28
let f28 = () => {
    //💚💔

    // const getFile = file => {
    // 	console.log(`start getting ${file}`);

    // 	return new Promise((resolve, reject) => {
    // 		let xhr = new XMLHttpRequest();
    // 		xhr.open("GET", file);
    // 		xhr.send();

    // 		xhr.addEventListener(`readystatechange`, ()=>{
    // 			if(xhr.readyState == 4){
    // 				console.log(`end getting ${file}`);
    // 				xhr.status < 400 ? resolve(JSON.parse(xhr.response)) : reject(file)
    // 			}
    // 		})
    // 	})
    // }

    // getFile(`files/users.json`)
    // 	.then(
    // 		users => {
    // 			console.log(users);

    // 			users.forEach(userName => {

    // 				console.log(`Start getting file ${userName}.json`);

    // 				getFile(`files/${userName}.json`)
    // 					.then(user => {
    // 						console.log(`End getting file ${userName}.json`);
    // 						console.log(user);
    // 					})
    // 					.catch(
    // 						err => console.log(`💔 in catch ${err}`)
    // 					)

    // 			})

    // 		}
    // 	)
    // 	.catch(
    // 		err => console.log(`💔 in catch ${err}`)
    // 	)

    // Promise
    // 	.all([
    // 		getFile('files/Alla.json'), // 1.5s
    // 		getFile('files/Anton.json'), // 0.9s
    // 		getFile('files/Vika.json'), // 0.7s
    // 		getFile('files/Ivan.json') // 0.7s
    // 	])
    // 	.then(
    // 		data => console.log(`💚 in resolve`, data)
    // 	)
    // 	.catch(
    // 		err => console.log(`💔 in catch, ${err}`)
    // 	)

    // Promise.all | Promise.allSettled

    // Promise
    // 	.allSettled([
    // 		getFile('files/Alla.json'), // 1.5s
    // 		getFile('files/Anton.json'), // 0.9s
    // 		getFile('files/Vika.json'), // 0.7s
    // 		getFile('files/Ivan.json') // 0.7s
    // 	])
    // 	.then(
    // 		data => {
    // 			console.log(`💚 in resolve`, data);
    // 			return data.filter(file => file.status === "fulfilled")
    // 		}
    // 	)
    // 	.then(
    // 		users => {
    // 			console.log(users); // filtered
    // 			return users.map(user => user.value);
    // 		}
    // 	)
    // 	.then(
    // 		users => console.log(users)
    // 	)

    // Promise
    // .allSettled([
    // 	getFile('files/Alla.json'), // 1.5s
    // 	getFile('files/Anton.json'), // 0.9s
    // 	getFile('files/Vika.json'), // 0.7s
    // 	getFile('files/Ivan.json') // 0.7s
    // ])
    // 	.then(
    // 		data => data.filter(file => file.status === "fulfilled").map(user => user.value)
    // 	)
    // 	.then(
    // 		users => console.log(users)
    // 	)


    // getFile(`files/users.json`)
    // 	.then(
    // 		users => {
    // 			console.log(users); // ['Alla', 'Anna', 'Anton', 'Vika', 'Ivan']
    // 			// [getFile(`files/Alla.json`), getFile(`files/Anna.json`)]

    // 			return Promise
    // 				.allSettled(users.map(user => getFile(`files/${user}.json`)))
    // 					.then(
    // 						data => data.filter(file => file.status === "fulfilled").map(user => user.value)
    // 					)
    // 		}
    // 	)
    // 	.then(
    // 		users => {
    // 			console.log(`💚 in second resolve`);
    // 			users.forEach(user => console.log(user.age))
    // 		}
    // 	)
    // 	.catch(
    // 		err => console.log(`💔 in catch ${err}`)
    // 	)


    // fetch

    // let xhr = new XMLHttpRequest();
    // xhr.open("GET", file);
    // xhr.send();

    // xhr.addEventListener(`readystatechange`, ()=>{
    // 	if(xhr.readyState == 4){
    // 		console.log(`end getting ${file}`);
    // 		xhr.status < 400 ? resolve(JSON.parse(xhr.response)) : reject(file)
    // 	}
    // })


    // fetch(`files/users.json`)
    // 	.then(
    // 		data => { // Response = new Promise();
    // 			console.log(data);
    // 			return data.ok ? data.json() : Promise.reject(data.statusText)
    // 		}
    // 	)
    // 	.then(
    // 		users => {
    // 			console.log(users)

    // 			return Promise
    // 				.allSettled(
    // 					users
    // 						.map(user => {
    // 							return fetch(`files/${user}.json`)
    // 								.then(file => file.ok ? file.json() : Promise.reject(file.statusText))
    // 						})
    // 				)
    // 				.then(
    // 					users => users.filter(user => user.status === "fulfilled").map(user => user.value)
    // 				)
    // 		}
    // 	)
    // 	.then(
    // 		users => console.log(users)
    // 	)
    // 	.catch(
    // 		err => console.log(`💔 in catch ${err}`)
    // 	)

    // async/await

    // const getFile = async file => {
    // 	try{
    // 		let request = await fetch(file),
    // 			response = request.ok ? await request.json() : await Promise.reject(request.statusText)

    // 		return response;

    // 	} catch(err){
    // 		console.log(err)
    // 	};
    // }

    // (async () => {

    // 	let users = await getFile(`files/users.json`);
    // 	console.log(users);

    // })()

    // let myPromise = new Promise((resolve, reject) => {
    // 	resolve({x: 10, y: 20})
    // 	reject([10, 20])
    // })

    // myPromise
    // 	.then(
    // 		data  => console.log(data.x, data.y)
    // 	)
    // 	.catch(
    // 		arr => console.log(data[0], data[y])
    // 	)

    // async/await

}
// ! 29
let f29 = () => {
    // 💔💚
    // async/await

    // const controller = async file => {
    // 	let request = await fetch(file);

    // 	if(request.ok){
    // 		return request.json();
    // 	} else{
    // 		throw new Error(request.statusText);
    // 	}
    // }

    // controller(`https://jsonplaceholder.typicode.com/photos`)
    // 	.then(
    // 		data => console.log(data)
    // 	)

    // const getCourses = async () => {

    // 	try{
    // 		let user = await controller(`files/user.json`);
    // 		console.log(user);

    // 		let role = await controller(`files/${user.role}.json`);
    // 		console.log(role);

    // 		let courses = await Promise
    // 			.allSettled(
    // 				role.courses.map(course => controller(`files/courses/${course}.json`))
    // 			)
    // 			.then(
    // 				files => files.filter(file => file.status === "fulfilled").map(file => file.value)
    // 			)
    // 			.then(
    // 				courses => courses.map(course => `${course.icon} ${course.title}`).join(`\n`)
    // 			)

    // 		console.log(courses);

    // 	} catch(err){
    // 		console.log(err);
    // 	}

    // };

    // const getCoursesBtn = document.querySelector(`#getCourses`);
    // getCoursesBtn.addEventListener(`click`, getCourses);


    // REST

    // API: https://jsonplaceholder.typicode.com/

    // 'https://jsonplaceholder.typicode.com/comments/1'

    // URL
    // 	protocol http/https
    // 	domain
    // 	path
    // 	queryParameter

    // METHOD
    // 	GET – получение данных
    // 	POST * – отправка данных на сервер в теле запроса (body)
    // 	PUT * – отправка данных на сервер в теле запроса (обновление ресурса)
    // 	PATCH * – отправка данных на сервер в теле запроса
    // 	DELETE

    // BODY

    // HEADERS – служебная информация (кодировка, сжатие, сервер, кеширование)

    // STATUS
    // 	100
    // 		101

    // 	200
    // 		201
    // 		204

    // 	300
    // 		301
    // 		302

    // 	400 – ошибка на фронте
    // 		401
    // 		403
    // 		404

    // 	500 – ошибка на сервере
    // 		502
    // 		503

    // https://jsonplaceholder.typicode.com/

    // REST – архитектура клиент-серверного взаимодействия
    // свод правил (рекомендаций), по которым клиент (web app, mobile app) и сервер должны между собой взаимодействовать

    // REST говорит, что нужно думать о данных, которые хранятся на сервере как о ресурсе.
    // У каждого ресурса на сервере есть свой URL. 

    // LIST – GET /posts // – запрос на ресурс posts
    // ITEM – GET /posts/:id // – запрос на ресурс posts с :id

    // ADD – POST /posts     body:{name: Alex, age: 21} // – запрос на ресурс posts c телом запроса, id всегда назначает только сервер
    // <== {id: 101, name: Alex, age: 21}

    // FULL UPDATE – PUT /posts/:id  body:{id: 101, name: Ivan} // в body отправляются все поля объекта
    // <== {id: 101, name: Ivan}

    // PARTIAL UPDATE – PATCH /posts/:id body:{name: ''} // в body отправляется только то, что изменилось
    // <== {id: 101, name: '', age: 21}

    // DELETE – /posts/:id
    // <== {}

    // RESTfull Api – сферический конь в вакууме 😌

    const API = "https://jsonplaceholder.typicode.com";

    const controller = async (file, method = "GET", obj) => {

        let options = {
            method: method,
            headers: {
                "Content-type": "application/json"
            }
        }

        if (obj)
            options.body = JSON.stringify(obj);

        console.log(options);

        let request = await fetch(file, options);

        if (request.ok) {
            return request.json();
        } else {
            throw new Error(request.statusText);
        }
    }

    (async () => {

        try {
            let posts = await controller(`${API}/posts`);
            console.log(posts);

            let lastPostId = posts[posts.length - 1].id;

            let lastPost = await controller(`${API}/posts/${lastPostId}`);
            console.log(lastPost);

            let lastPostComments = await controller(`${API}/posts/${lastPostId}/comments`);
            console.log(lastPostComments);

            let lastPostCommentsSecond = await controller(`${API}/comments?postId=${lastPostId}`);
            console.log(lastPostCommentsSecond);

            let newPost = {
                userId: 10,
                title: "Cat",
                body: "Cat info"
            }

            let newPostAdded = await controller(`${API}/posts`, "POST", newPost);

            // button.innerHTML = 'Loading...';
            // button.style.pointerEvents = true

            console.log(newPostAdded);

            // if(newPostAdded){
            // 	button.innerHTML = 'Added!';
            // 	setTimeout(() => button.innerHTML = 'Add post again!',100);
            // 	button.style.pointerEvents = true;
            // }

            // let jokes = await controller(`https://api.chucknorris.io/jokes/random`, "POST", {});
            // console.log(jokes);


            let changedPostPut = await controller(`${API}/posts/99`, "PUT", { cat: "privetik", id: 10000 });
            console.log(changedPostPut);

            let changedPostPatch = await controller(`${API}/posts/99`, "PATCH", { cat: "privetik", id: 10000 });
            console.log(changedPostPatch);

            let deletedPost = await controller(`${API}/posts/99`, "DELETE");
            console.log(deletedPost);


        } catch (err) {
            console.log(err);
        }


    })();

}
// ! 30
let f30 = () => {
    const controller = async (url, method = "GET", obj) => {

        let options = {
            method: method,
            headers: {
                "content-type": "application/json"
            }
        }

        if (obj)
            options.body = JSON.stringify(obj);

        let request = await fetch(url, options);

        if (request.ok) {
            return request.json();
        } else {
            throw new Error(request.statusText);
        }
    }

    // const API = `https://61e82124e32cd90017acc07e.mockapi.io`;

    // (async () => {

    // 	try{

    // 		let users = await controller(`${API}/users`);
    // 		console.log(users);

    // 		let usersAnimals = users
    // 			.reduce((animalsObj, user) => {
    // 				animalsObj[user.animal] = [];
    // 				return animalsObj;
    // 			}, {});
    // 		console.log(`*** create object of animals names ****`);
    // 		console.log(usersAnimals); // create object of all animals, that avaliable for all users

    // 		let animals = Promise // fill each animal
    // 			.allSettled(
    // 				Object.keys(usersAnimals)
    // 					.map(animal => {
    // 						console.log(`start getting ${animal} list`);
    // 						return controller(`${API}/${animal}`)
    // 							.then(data => {
    // 								usersAnimals[animal] = data;

    // 								console.log(`getted ${animal} list`);
    // 								console.log(usersAnimals);
    // 							})
    // 					})
    // 			)
    // 			.then(
    // 				() => {
    // 					console.log(`*** final object of animals names ****`);
    // 					console.log(usersAnimals);

    // 					users.forEach(async user => {
    // 						let block = document.createElement(`div`);
    // 						block.className = `user`;

    // 						block.innerHTML = `<h3>Name: ${user.name}</h3>`;

    // 						let userAnimalName = document.createElement(`h4`);
    // 						userAnimalName.innerHTML = `Animal name: ${user.animalName ? user.animalName : ``}`;

    // 						let animalAvaliableNames = usersAnimals[user.animal];

    // 						let animalsSelect = document.createElement(`select`);
    // 						animalsSelect.innerHTML = animalAvaliableNames
    // 							.map(animal => `<option value="${animal.name}" ${user.animalName === animal.name ? `selected` : ``}>${animal.name}</option>`)
    // 							.join(``);

    // 						animalsSelect.addEventListener(`change`, () => {
    // 							console.log(animalsSelect.value);

    // 							let changeUser = controller(`${API}/users/${user.id}`, "PUT", {animalName: animalsSelect.value})
    // 									.then(user => {
    // 										console.log(user);
    // 										userAnimalName.innerHTML = `Animal name: ${user.animalName}`;
    // 									})
    // 						})

    // 						block.append(userAnimalName, animalsSelect);

    // 						document.body.append(block);
    // 					})
    // 				}
    // 			)

    // 	} catch(err){
    // 		console.log(`in catch: ${err}`)
    // 	}

    // })();
}